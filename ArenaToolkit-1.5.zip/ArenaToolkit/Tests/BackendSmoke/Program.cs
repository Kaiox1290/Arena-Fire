using Arena.Core;
var root = Path.Combine(Path.GetTempPath(), "fb_" + Guid.NewGuid().ToString("N")); Directory.CreateDirectory(root);
var src = Path.Combine(root, "src"); Directory.CreateDirectory(Path.Combine(src, "UI"));
File.WriteAllText(Path.Combine(src, "a.txt"), "hello"); File.WriteAllBytes(Path.Combine(src, "UI", "b.dtx"), new byte[300]);
File.WriteAllText(Path.Combine(src, "Thumbs.db"), "junk"); File.WriteAllText(Path.Combine(src, "UI", "x.txt"), "x"); File.WriteAllText(Path.Combine(src, "UI", "x.txt.bak"), "bak");
int fails = 0; void C(string n, bool ok, string d = "") { Console.WriteLine($"{(ok ? "PASS" : "FAIL")} {n} {d}"); if (!ok) fails++; }
var rez = Path.Combine(root, "t.rez"); var warns = new List<string>();
try { RezBackend.PackStaged(src, rez, new Job(), default, w => warns.Add(w)); C("PackStaged ok", true); } catch (Exception e) { C("PackStaged", false, e.Message); }
var o = Path.Combine(root, "o"); RezBackend.Unpack(rez, o, new Job(), default);
var names = Directory.GetFiles(o, "*", SearchOption.AllDirectories).Select(f => Path.GetRelativePath(o, f).Replace('\\', '/')).OrderBy(x => x).ToList();
Console.WriteLine("   packed entries: " + string.Join(", ", names));
C("junk (Thumbs.db, .bak next to its original) not packed", !names.Any(n => n.Contains("Thumbs") || n.EndsWith(".bak")) && names.Contains("UI/x.txt"));
C("real files packed", names.Contains("a.txt") && names.Contains("UI/b.dtx"));
C("staging folder cleaned up", !Directory.GetDirectories(Path.GetTempPath(), "arena_stage_*").Any());
// built-in reader must refuse the real-layout archive with a clear message (not crash)
try { RezArchive.Open(rez); C("built-in reader on real-layout REZ", false, "(it accepted it?)"); } catch (InvalidDataException e) { C("built-in reader refuses real-layout REZ clearly", true, e.Message.Substring(0, 40)); } catch (Exception e) { C("built-in reader threw wrong type", false, e.GetType().Name); }
Console.WriteLine(fails == 0 ? "ALL PASS" : $"{fails} FAILED"); return fails;

namespace Arena.Core;
// Test-only stand-in (the real ImageTools needs Windows GDI+). Behaves like "not a readable image".
public static class ImageTools { public static (int w, int h, byte[] bgra) LoadBgra(string p) => throw new InvalidDataException("stub"); }

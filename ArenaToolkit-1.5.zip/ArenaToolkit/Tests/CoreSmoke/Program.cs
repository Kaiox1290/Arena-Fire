using Arena.Core;
var root = Path.Combine(Path.GetTempPath(), "arn_t_" + Guid.NewGuid().ToString("N")); Directory.CreateDirectory(root);
Workspace.Init(Path.Combine(root, "ws"));
int fails = 0; void Check(string n, bool ok, string d = "") { Console.WriteLine($"{(ok ? "PASS" : "FAIL")}  {n} {d}"); if (!ok) fails++; }

// 1) REZ pack/extract/verify round trip
var src = Path.Combine(root, "src"); Directory.CreateDirectory(Path.Combine(src, "UI", "Sub"));
File.WriteAllText(Path.Combine(src, "a.txt"), "hello"); File.WriteAllText(Path.Combine(src, "UI", "b.dtx"), "bbb");
File.WriteAllText(Path.Combine(src, "UI", "Sub", "c.longext"), "ccc"); File.WriteAllText(Path.Combine(src, "noext"), "n");
var rez = Path.Combine(root, "t.rez");
try { RezArchive.Pack(src, rez, new Job(), default); Check("rez pack+verify", true); } catch (Exception e) { Check("rez pack+verify", false, e.Message); }
try { var a = RezArchive.Open(rez); var o = Path.Combine(root, "out"); a.ExtractAll(o, new Job(), default);
  Check("rez extract", File.ReadAllText(Path.Combine(o, "UI", "Sub", "c.longext")) == "ccc"); } catch (Exception e) { Check("rez extract", false, e.Message); }

// 1b) pack cancelled mid-way leaves partial file?
var rez2 = Path.Combine(root, "cancel.rez"); var cts = new CancellationTokenSource(); cts.Cancel();
try { RezArchive.Pack(src, rez2, new Job(), cts.Token); } catch (OperationCanceledException) { }
Check("cancelled pack leaves no half file", !File.Exists(rez2), File.Exists(rez2) ? "(partial file left behind)" : "");

// 1c) duplicate-case / reserved names on extract: names CON / trailing dot
var bad = Path.Combine(root, "bad"); Directory.CreateDirectory(bad); File.WriteAllText(Path.Combine(bad, "x.txt"), "x");
// 2) Pipeline with a fake one-way "copy" tool + reverse copy tool
bool win = OperatingSystem.IsWindows();
string MakeTool(string name, string unixBody, string winBody)
{
    var p = Path.Combine(root, name + (win ? ".bat" : ".sh"));
    File.WriteAllText(p, win ? "@echo off\r\n" + winBody + "\r\n" : "#!/bin/sh\n" + unixBody + "\n");
    if (!win) System.Diagnostics.Process.Start("chmod", $"+x {p}")!.WaitForExit();
    return p;
}
var sh = MakeTool("cp", "cp \"$1\" \"$2\"", "copy /y %1 %2 >nul");
var cfg = new ArenaConfig(); cfg.Tools["fwd"] = new ExternalToolCfg { Path = sh, Args = { "{in}", "{out}" } }; cfg.Tools["rev"] = new ExternalToolCfg { Path = sh, Args = { "{in}", "{out}" } };
var spec = new ConvSpec("copy", "test", "fwd", "rev", ".bin");
var inp = Path.Combine(root, "in"); Directory.CreateDirectory(inp);
for (int i = 0; i < 8; i++) { var d = Path.Combine(inp, "d" + i); Directory.CreateDirectory(d); File.WriteAllText(Path.Combine(d, "item.cft"), "data" + i); }
var outDir = Path.Combine(root, "o2"); var errs = new System.Collections.Concurrent.ConcurrentBag<string>();
Parallel.ForEach(Directory.GetFiles(inp, "*.cft", SearchOption.AllDirectories), f => { try { Pipeline.Convert(cfg, spec, f, outDir, Workspace.BackupDir, default); } catch (Exception e) { errs.Add(e.Message); } });
int made = Directory.GetFiles(outDir).Length;
Check("parallel same-name conversions: 8 outputs, no errors", made == 8 && errs.IsEmpty, $"outputs={made} errors={errs.Count} first={errs.FirstOrDefault()}");
// backups of same name different content
Check("backup keeps all 8 originals", Directory.GetFiles(Workspace.BackupDir).Length == 8, $"found {Directory.GetFiles(Workspace.BackupDir).Length}");
// 3) failing reverse leaves orphan output?
var cfg2 = new ArenaConfig(); cfg2.Tools["fwd"] = cfg.Tools["fwd"]; var bad_sh = MakeTool("bad", "exit 3", "exit /b 3");
cfg2.Tools["rev"] = new ExternalToolCfg { Path = bad_sh, Args = { "{in}", "{out}" } };
var od3 = Path.Combine(root, "o3"); try { Pipeline.Convert(cfg2, spec, Path.Combine(inp, "d0", "item.cft"), od3, Workspace.BackupDir, default); } catch { }
Check("failed reverse tool removes unverified output", !Directory.Exists(od3) || Directory.GetFiles(od3).Length == 0, $"left={ (Directory.Exists(od3) ? Directory.GetFiles(od3).Length : 0)}");
// 4) DTX encode header byte positions
var px = new byte[4 * 4 * 4]; var dtx = DtxCodec.Encode(4, 4, px, DtxCodec.Bpp32, 1);
Check("DTX header: byte24=texture group(0), byte25=mips to use(1)", dtx[24] == 0 && dtx[25] == 1, $"b24={dtx[24]} b25={dtx[25]}");
var dec = DtxCodec.Decode(dtx); Check("DTX 32-bit round trip", dec.w == 4 && dec.h == 4);
// 5) relative tool path
Environment.CurrentDirectory = root; var cfg3 = new ArenaConfig(); cfg3.Tools["fwd"] = new ExternalToolCfg { Path = Path.GetFileName(sh), Args = { "{in}", "{out}" } };
try { Pipeline.Convert(cfg3, new ConvSpec("c", "t", "fwd", null, ".bin", true), Path.Combine(inp, "d1", "item.cft"), Path.Combine(root, "o4"), Workspace.BackupDir, default); Check("relative tool Path works", true); }
catch (Exception e) { Check("relative tool Path works", false, e.Message); }
Console.WriteLine(fails == 0 ? "ALL PASS" : $"{fails} FAILED"); return fails;

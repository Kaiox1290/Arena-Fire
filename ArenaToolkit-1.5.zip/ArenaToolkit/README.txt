Team Arena Toolkit  v1.5  for Arena Fire  (v1.2 base + CrossFire 2.0 converters + community tools, reviewed)
==========================================================================
1) Install .NET 8 SDK  (https://dotnet.microsoft.com/download/dotnet/8.0)
2) Double-click build.bat  ->  dist\ArenaTool.exe

How it works
- Pick a tool on the left (REZ Unpack, REZ Pack, DTX -> PNG, PNG -> DTX, Resize, Icons, Config & DAT).
- Drop files or folders anywhere in the window (also over the preview / text boxes): processing starts
  automatically, in parallel, with live progress and a per-file status.
- Files dropped while a job is running are queued and start by themselves when it finishes.
- REZ Unpack also converts every DTX inside to PNG (switch it off with the checkbox).
  Each unpack goes to its own folder (name, name_2, ...) - nothing is overwritten or mixed.
- REZ Pack skips Thumbs.db / desktop.ini, temp files and the .bak files made by the Config editor.
  The helper PNG next to a .dtx is never packed. If you EDITED that PNG, the .dtx is re-encoded from it
  automatically (same format, header and mip count as the original). If you did not touch it, the original
  .dtx bytes are packed unchanged. A note in the toast ("Details") lists every re-encoded texture.
- PNG -> DTX: 32-bit by default (exact). Tick "Compress to DXT" for much smaller files
  (DXT1 when the image is opaque, DXT5 when it has transparency).
  If the original .dtx sits next to the image (foo.dtx beside foo.png or foo.dtx.png) its header, pixel format
  and mip count are reused, so the game sees the same kind of texture.
- Resize: type a size or % first, then drop. "Run again" re-applies to the list.
- Config & DAT: select a file to edit ini/cfg/txt (a .bak is kept), or inspect dat/dll in hex.
  Unsaved edits are remembered when you click another file, and you are asked before exiting.
  Non-UTF-8 files (old ANSI / Korean / Chinese configs) are saved back byte-for-byte; line endings are kept.
- Export ZIP packs everything produced into one .zip.
- Window is resizable; on small widths the layout becomes a single column.
- Respects Windows "Show animations" (reduced motion): when off, all motion is disabled.
- Errors have a code (ARN-AREA-KIND), a hint and a full report; logs: %LocalAppData%\TeamArena\logs (kept 14 days)

What's new in 1.2
- DTX   New encoder: principal-axis + least-squares endpoints (better gradients), exact flat colours, transparent
        pixels no longer pollute visible colours, DXT5 alpha picks the best of two modes (hard cut-outs stay exact),
        DXT3 support, optional mip chain (kept from the original texture), big textures encode in parallel.
- DTX   Warnings for non power-of-two / non multiple-of-4 sizes; DXT1 + transparency is upgraded to DXT5 with a note.
- DTX   Header validation (size, version), 64-bit safe size checks, clearer errors.
- FIX   Deep unpack: textures that could not be converted were silently skipped; now reported ("done" + warning list).
- FIX   Repack ignored edits made to the PNG next to a .dtx; now synced (see above).
- FIX   Resize used GDI+ and left halos on transparent edges. Now Lanczos-3 on alpha-weighted colour; also accepts .dtx.
- FIX   REZ: two entries with the same path no longer overwrite each other during parallel extract; names like CON/NUL
        and trailing dots are made safe; half-written files are removed; pack is written to a temp file and swapped in.
- FIX   Config editor: saving an ANSI file with characters it cannot store (e.g. Arabic) used to turn them into "?";
        now you are asked and can save as UTF-8. Ctrl+S saves.
- FIX   Export ZIP and PNG/DTX/icon outputs are written atomically (cancel or crash leaves no broken file).
- NEW   Icons: each icon also exported as a multi-size .ico (256/64/48/32/16 when the file has them).
- NEW   Hex viewer shows the first 64 KB (was 8 KB).
- NEW   App icon (app.ico: 256/128/64/48/32/24/20/16 px) used by the .exe, taskbar and Alt-Tab. Source art: Assets\icon.png.
- NEW   Self-test:  ArenaTool.exe --selftest  (or selftest.bat) checks the codec, resize and REZ round trip.

What's new in 1.1
- FIX  Config editor could corrupt non-UTF-8 files on save and changed their line endings. Now lossless + atomic save.
- FIX  Unsaved edits were silently lost when selecting another file.
- FIX  Files could not be dropped over text boxes (preview area, resize fields).
- FIX  Two files with the same name in one batch could overwrite each other; unpack folders could merge.
- FIX  PNG -> DTX resampled the image slightly (DPI / edge blur); it is now a pixel-exact conversion.
- FIX  DTX header: "mipmaps to use" was written to the wrong byte (texture-group byte). Test in game.
- FIX  Repacking an unpacked folder also packed the helper PNGs.
- FIX  Export ZIP while busy opened the dialog and then did nothing; closing mid-job could leave half-written files.
- FIX  REZ: looping directory tables are detected; names REZ cannot store (non Latin-1) give a clear message.
- NEW  Job queue, DXT1/DXT5 compression, DTX format shown in the inspector, REZ total size.
- FASTER  Big folder drops no longer freeze the UI; window shadow no longer re-renders every frame;
          background glows cached and capped at 30 fps; one REZ at a time (each is already parallel inside).

Known limits
- REZ: LithTech v1 layout. Encrypted/modified REZ variants are not supported.
- DTX: reads DXT1/DXT3/DXT5 + 32-bit. Palette / 8-bit / 16-bit formats are skipped with a clear message.
- DTX written by this tool has a single mipmap level unless it is re-encoded from an existing .dtx (then it keeps that texture's mip count).
- Mip levels are stored largest first (this is how the decoder reads your files); verify the first mipmapped texture in game.

CrossFire 2.0 converters  (new in 1.3, merged from the converter build)
- CFT <-> CSV, LTC <-> LTA, ENC <-> TXT, DAT -> LTA (-v1 required), FXF/FCF 3.0 -> 2.0, LTB info (read only).
- The tool contains NO decryption / conversion algorithm. Put the real tools in config.json
  (Tools.<name>.Path + Args with {in} {out} {outdir} {name}); see config.example.json. Press the Config button.
  Path may be absolute, next to the exe, or on PATH. Missing tool = clear message, nothing is converted.
- Every file: SHA-256 -> copy to backup\ -> convert -> convert back -> compare. A mismatch deletes the output and shows the
  first different offset. One-way converters (DAT, FXF/FCF) are reported as "unverified", never as success.
- MSZ CTL TAD ATL NAV: listed as unsupported in the report, files untouched (formats unconfirmed).
- Logs/reports: <WorkDir>\logs\log.txt and report_*.json (Report button). Default WorkDir = Documents\Team Arena Output.
- Round-trip needs the tools to reproduce the original BYTE FOR BYTE. If an encrypt tool is not deterministic, set
  "RequireRoundTrip": false in config.json (results are then reported as "unverified").

Fixes in 1.3 (found by review + executed tests)
- DTX: the converter build still had the 1.0 encoder (mip count written to the texture-group byte); 1.2 codec is used.
- Pipeline: parallel conversions of files with the same name could share one output name (wrong file verified);
  names are now reserved under a lock.
- Pipeline: when the reverse converter failed or the job was cancelled, an UNVERIFIED output was left behind; now removed.
- Tool paths: relative / PATH-based tool paths are resolved to an absolute path.
- REZ Pack: the written archive is re-opened and every entry (list, size, SHA-256) is checked BEFORE it replaces the output.
  (The old check compared with the source folder, which is wrong when a .dtx is re-encoded from its PNG.)
- Error codes for converter failures (ARN-*-CFG / EXT / ROUNDTRIP) are kept in the 1.2 error hub.

Tests: dotnet run --project Tests\CoreSmoke   (no packages; REZ, pipeline, round trip, cancel, DTX header)
NOT verified here: the WPF window (needs Windows to build) and anything that depends on the game itself
(REZ layout accepted by the real client, DTX flags, mip order). Test one packed REZ in the game before relying on it.

v1.4: community tools plugged in  (run setup.bat, then build.bat)
- setup.bat fetches, at the commit tested with this toolkit, into ThirdParty\ :
    CFRezManager     (github.com/LRolinx/CFRezManager)       - REZ reader/writer used for the real-client layout
    cf-model-exporter (github.com/35580930/cf-model-exporter) - Python LTB -> GLB exporter
  Nothing from them is copied into this project's files: four REZ source files are LINKED at build time, and the exporter
  is called as an external tool. Neither repository has a LICENSE file: use them unmodified on your own machine and do not
  redistribute them (or this folder with ThirdParty\ inside) without the authors' permission.
- With ThirdParty present, build.bat prints "Real-client REZ layout: ON". REZ Unpack / Pack / the REZ preview then use the
  CF Rez Manager reader+writer (encrypted directory tables, MD5 per file). Pack = stage (junk and helper PNGs removed, edited
  PNGs re-encoded to DTX) -> write -> re-read and compare every entry (path, size, SHA-256) -> delete the output if anything differs.
  Writer limits (from CF Rez Manager): ASCII names, 1-4 character extension, every file needs an extension.
- Without ThirdParty the built-in plain v1 writer is used and every pack carries a warning (the real client probably rejects it).
- New tool "LTB -> GLB" (needs Python 3.8+ on PATH): Tools.ltb_to_glb in config.json, preconfigured in config.example.json
  ({app} = folder of ArenaTool.exe; build.bat copies the exporter next to the exe). One-way, reported as "unverified".
- Map DAT -> GLB (cf_dat_exporter.py) writes a folder, not one file, so it is not wired in. By hand:
    python ThirdParty\cf-model-exporter\cf_dat_exporter.py --dat WORLD.dat --tex <unpacked REZ root> --out <folder> --glb
- Not used: bxclip/Tool-Crossfire (only binaries in a .rar, no source).
Tests: Tests\BackendSmoke (after setup.bat) checks pack -> unpack -> junk filtering -> cleanup with the real REZ layout.
NOT verified: the WPF window build, and that YOUR client accepts the packed REZ (test one in the game).

Build the .exe
- On Windows: build.bat  ->  dist\ArenaTool.exe   (setup.bat first for the real-client REZ layout).
- Without a Windows PC: put this folder in a PRIVATE GitHub repository; .github\workflows\build.yml builds the exe on GitHub's
  Windows runner (Actions -> "Build Arena Tool" -> Run workflow -> download the artifact "ArenaTool").
- Do not share the exe or repository publicly: it links CF Rez Manager sources, which have no license.

using System.Windows;
using Arena.Core;

namespace Arena;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        if (e.Args.Any(x => x.Equals("--selftest", StringComparison.OrdinalIgnoreCase)))
        {
            string report = SelfTest.Run();
            MessageBox.Show(report, "Team Arena · self-test", MessageBoxButton.OK, MessageBoxImage.Information);
            Shutdown();
            return;
        }

        // Respect Windows "Show animations" (reduced motion): zero every XAML animation duration.
        if (!SystemParameters.ClientAreaAnimation)
            foreach (var k in new[] { "DurFast", "DurMed", "DurSlow" })
                Resources[k] = new Duration(TimeSpan.Zero);

        DispatcherUnhandledException += (_, a) => { ErrorHub.Report(a.Exception, "UI"); a.Handled = true; };
        AppDomain.CurrentDomain.UnhandledException += (_, a) =>
        {
            if (a.ExceptionObject is not Exception ex) return;
            ErrorHub.Report(ex, "APP", null, true);
            try
            {
                MessageBox.Show($"Team Arena hit a fatal error and must close.\n\n{ex.Message}\n\nA report was saved in:\n{ErrorHub.LogDir}",
                                "Team Arena", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch { }
        };
        TaskScheduler.UnobservedTaskException += (_, a) => { ErrorHub.Report(a.Exception, "TASK", null, true); a.SetObserved(); };
        base.OnStartup(e);
    }
}

@echo off
setlocal
title Team Arena - Build EXE
echo ==============================================
echo    Team Arena Toolkit  -  Build to EXE
echo ==============================================
where dotnet >nul 2>nul
if errorlevel 1 (
  echo [ERROR] .NET 8 SDK not found.
  echo Install it from: https://dotnet.microsoft.com/download/dotnet/8.0
  pause
  exit /b 1
)
for /f "tokens=1 delims=." %%v in ('dotnet --version') do set SDKMAJOR=%%v
if %SDKMAJOR% LSS 8 (
  echo [ERROR] Found .NET SDK %SDKMAJOR%. The .NET 8 SDK or newer is required.
  echo Install it from: https://dotnet.microsoft.com/download/dotnet/8.0
  pause
  exit /b 1
)
echo Building single-file EXE ...
dotnet publish ArenaTool.csproj -c Release -r win-x64 --self-contained true ^
  -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true ^
  -p:EnableCompressionInSingleFile=true -p:DebugType=none -o dist
if errorlevel 1 (
  echo [ERROR] Build failed. Send the messages above to Team Arena.
  pause
  exit /b 1
)
if exist ThirdParty\CFRezManager\Archives\RezArchiveWriter.cs (echo Real-client REZ layout: ON  ^(CF Rez Manager^)) else (echo Real-client REZ layout: OFF - run setup.bat first, then build again)
if exist ThirdParty\cf-model-exporter\cf_ltb_exporter.py (
  xcopy /e /i /y /q ThirdParty\cf-model-exporter dist\ThirdParty\cf-model-exporter >nul
  echo LTB to GLB exporter copied to dist\ThirdParty\cf-model-exporter
)
echo.
echo DONE  ->  dist\ArenaTool.exe
start "" dist
pause

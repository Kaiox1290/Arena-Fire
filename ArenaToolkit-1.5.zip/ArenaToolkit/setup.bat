@echo off
setlocal
title Team Arena - fetch third-party tools
cd /d "%~dp0"
echo ==============================================================
echo  Fetches the community tools into ThirdParty\  (nothing is copied
echo  into this project's own source files).
echo.
echo  NOTE: neither repository contains a LICENSE file. They are used here
echo  unmodified, on your own machine. Do not redistribute them or this
echo  folder with ThirdParty\ inside. Ask the authors if you want to publish.
echo ==============================================================
where git >nul 2>nul
if errorlevel 1 (
  echo [ERROR] git not found. Install Git for Windows, or download these ZIPs by hand and unpack them to:
  echo   https://github.com/LRolinx/CFRezManager      -^>  ThirdParty\CFRezManager
  echo   https://github.com/35580930/cf-model-exporter -^>  ThirdParty\cf-model-exporter
  if not defined CI pause
  exit /b 1
)
if not exist ThirdParty mkdir ThirdParty

call :fetch https://github.com/LRolinx/CFRezManager.git ThirdParty\CFRezManager 0a93f3ab73b1bee8c4e1546d6864894981b67e66
if errorlevel 1 goto fail
call :fetch https://github.com/35580930/cf-model-exporter.git ThirdParty\cf-model-exporter 76d9242805933b0bc3442dae6996cbc6890aa740
if errorlevel 1 goto fail

echo.
echo DONE. Now run build.bat (the real-client REZ layout is switched on automatically).
if not defined CI pause
exit /b 0

:fetch
rem %1 = url, %2 = folder, %3 = commit that was tested with this toolkit
if exist "%~2\.git" (
  echo %~2 already present.
  exit /b 0
)
git init -q "%~2" || exit /b 1
git -C "%~2" remote add origin %1
git -C "%~2" fetch --depth 1 origin %3 || exit /b 1
git -C "%~2" checkout -q FETCH_HEAD || exit /b 1
echo %~2 -^> %3
exit /b 0

:fail
echo [ERROR] download failed. Check your internet connection or fetch the repositories by hand (see above).
if not defined CI pause
exit /b 1

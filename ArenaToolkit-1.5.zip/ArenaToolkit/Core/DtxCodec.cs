namespace Arena.Core;

public sealed record DtxInfo(int Width, int Height, int Bpp, int Mips, int Flags, int Version, int Sections);

/// <summary>Header + format of an existing .dtx, reused so a re-encoded texture keeps its flags, group, command string and mip count.</summary>
public sealed record DtxTemplate(byte[] Header, int Bpp, int Mips, byte[] Trailing);

/// <summary>LithTech DTX texture codec: decode DXT1/3/5 + 32-bit; encode 32-bit, DXT1, DXT3, DXT5 with optional mip chain.</summary>
public static class DtxCodec
{
    public const int HeaderSize = 164;
    public const int Bpp32 = 3, BppDxt1 = 4, BppDxt3 = 5, BppDxt5 = 6;
    const int MaxSize = 8192;

    // ───────────────────────── header ─────────────────────────
    public static DtxInfo ReadInfo(byte[] d)
    {
        if (d.Length < HeaderSize) throw new InvalidDataException("File is too small to be a DTX texture.");
        uint resType = BitConverter.ToUInt32(d, 0);
        int ver = BitConverter.ToInt32(d, 4);
        if (resType != 0 || ver > -2 || ver < -6)
            throw new InvalidDataException($"Unsupported or invalid DTX header (version {ver}).");

        int w = BitConverter.ToUInt16(d, 8), h = BitConverter.ToUInt16(d, 10);
        if (w == 0 || h == 0 || w > MaxSize || h > MaxSize)
            throw new InvalidDataException($"Invalid DTX size {w}x{h}.");

        return new DtxInfo(w, h, d[26], BitConverter.ToUInt16(d, 12), BitConverter.ToInt32(d, 16), ver, BitConverter.ToUInt16(d, 14));
    }

    public static string FormatName(int bpp) => bpp switch
    {
        0 => "8-bit palette", 1 => "8-bit", 2 => "16-bit", 3 => "32-bit",
        4 => "DXT1", 5 => "DXT3", 6 => "DXT5", 7 => "32-bit palette",
        _ => "format " + bpp
    };

    /// <summary>Human readable one-liner for the inspector: format, header version, mip count.</summary>
    public static string Info(byte[] d)
    {
        if (d.Length < HeaderSize) return "";
        return $"{FormatName(d[26])}  ·  v{BitConverter.ToInt32(d, 4)}  ·  {BitConverter.ToUInt16(d, 12)} mip";
    }

    static int LevelBytes(int w, int h, int bpp) =>
        bpp == Bpp32 ? w * h * 4 : ((w + 3) / 4) * ((h + 3) / 4) * (bpp == BppDxt1 ? 8 : 16);

    public static int MaxMips(int w, int h)
    {
        int n = 1;
        while ((w >> n) > 0 || (h >> n) > 0) n++;
        return n;
    }

    static long ChainBytes(int w, int h, int bpp, int mips)
    {
        long total = 0;
        for (int m = 0; m < mips; m++) total += LevelBytes(Math.Max(1, w >> m), Math.Max(1, h >> m), bpp);
        return total;
    }

    static bool IsPow2(int v) => v > 0 && (v & (v - 1)) == 0;

    // ───────────────────────── DECODE ─────────────────────────
    /// <summary>Decodes the largest mip level to BGRA.</summary>
    public static (int w, int h, byte[] bgra) Decode(byte[] d)
    {
        var info = ReadInfo(d);
        int w = info.Width, h = info.Height, bpp = info.Bpp;
        var o = new byte[w * h * 4];
        switch (bpp)
        {
            case Bpp32:
                Need(d, w * h * 4);
                Buffer.BlockCopy(d, HeaderSize, o, 0, o.Length);
                break;
            case BppDxt1: case BppDxt3: case BppDxt5:
                Need(d, LevelBytes(w, h, bpp));
                Dxt(d, HeaderSize, w, h, bpp, o);
                break;
            default:
                throw new NotSupportedException($"DTX pixel format '{FormatName(bpp)}' is not supported yet.");
        }
        return (w, h, o);
    }

    static void Need(byte[] d, long bytes)
    {
        if (d.Length < HeaderSize + bytes) throw new InvalidDataException("DTX pixel data is truncated.");
    }

    static void Rgb565(int c, Span<byte> p, int at)
    {
        int r = (c >> 11) & 31, g = (c >> 5) & 63, b = c & 31;
        p[at] = (byte)(r << 3 | r >> 2);
        p[at + 1] = (byte)(g << 2 | g >> 4);
        p[at + 2] = (byte)(b << 3 | b >> 2);
    }

    static void Dxt(byte[] s, int off, int w, int h, int kind, byte[] o)
    {
        int bw = (w + 3) / 4, bh = (h + 3) / 4, bs = kind == BppDxt1 ? 8 : 16;
        Span<byte> pal = stackalloc byte[16];
        Span<byte> al = stackalloc byte[16];

        for (int by = 0; by < bh; by++)
        for (int bx = 0; bx < bw; bx++)
        {
            int p = off + (by * bw + bx) * bs;
            int cp = kind == BppDxt1 ? p : p + 8;
            int c0 = s[cp] | s[cp + 1] << 8, c1 = s[cp + 2] | s[cp + 3] << 8;
            Rgb565(c0, pal, 0); Rgb565(c1, pal, 4);
            bool four = c0 > c1 || kind != BppDxt1;
            for (int k = 0; k < 3; k++)
            {
                pal[8 + k] = (byte)(four ? (2 * pal[k] + pal[4 + k]) / 3 : (pal[k] + pal[4 + k]) / 2);
                pal[12 + k] = (byte)(four ? (pal[k] + 2 * pal[4 + k]) / 3 : 0);
            }
            pal[3] = pal[7] = pal[11] = 255;
            pal[15] = (byte)(four ? 255 : 0);
            uint idx = BitConverter.ToUInt32(s, cp + 4);

            if (kind == BppDxt3)
            {
                ulong bits = BitConverter.ToUInt64(s, p);
                for (int i = 0; i < 16; i++) al[i] = (byte)(((bits >> (4 * i)) & 0xF) * 17);
            }
            else if (kind == BppDxt5)
            {
                int a0 = s[p], a1 = s[p + 1];
                ulong bits = 0;
                for (int i = 0; i < 6; i++) bits |= (ulong)s[p + 2 + i] << (8 * i);
                for (int i = 0; i < 16; i++)
                {
                    int code = (int)((bits >> (3 * i)) & 7), a;
                    if (code == 0) a = a0;
                    else if (code == 1) a = a1;
                    else if (a0 > a1) a = ((8 - code) * a0 + (code - 1) * a1) / 7;
                    else if (code < 6) a = ((6 - code) * a0 + (code - 1) * a1) / 5;
                    else a = code == 6 ? 0 : 255;
                    al[i] = (byte)a;
                }
            }

            for (int i = 0; i < 16; i++)
            {
                int x = bx * 4 + (i & 3), y = by * 4 + (i >> 2);
                if (x >= w || y >= h) continue;
                int ci = (int)((idx >> (2 * i)) & 3), q = (y * w + x) * 4;
                o[q] = pal[ci * 4 + 2]; o[q + 1] = pal[ci * 4 + 1]; o[q + 2] = pal[ci * 4];
                o[q + 3] = kind == BppDxt1 ? pal[ci * 4 + 3] : al[i];
            }
        }
    }

    /// <summary>True when both images show the same picture. Colour of fully transparent pixels is ignored (editors zero it on save).</summary>
    public static bool SamePixels(byte[] a, byte[] b)
    {
        if (a.Length != b.Length) return false;
        for (int i = 0; i < a.Length; i += 4)
        {
            if (a[i + 3] != b[i + 3]) return false;
            if (a[i + 3] == 0) continue;
            if (a[i] != b[i] || a[i + 1] != b[i + 1] || a[i + 2] != b[i + 2]) return false;
        }
        return true;
    }

    // ───────────────────────── template ─────────────────────────
    /// <summary>Reads header + format of an existing .dtx (null when it is a format the encoder cannot reproduce).</summary>
    public static DtxTemplate? ReadTemplate(byte[] d)
    {
        DtxInfo i;
        try { i = ReadInfo(d); }
        catch (InvalidDataException) { return null; }
        if (i.Bpp < Bpp32 || i.Bpp > BppDxt5) return null;

        int mips = Math.Clamp(i.Mips, 1, MaxMips(i.Width, i.Height));
        while (mips > 1 && HeaderSize + ChainBytes(i.Width, i.Height, i.Bpp, mips) > d.Length) mips--;
        long expected = HeaderSize + ChainBytes(i.Width, i.Height, i.Bpp, mips);
        if (expected > d.Length) return null;

        var header = new byte[HeaderSize];
        Buffer.BlockCopy(d, 0, header, 0, HeaderSize);
        byte[] trailing = Array.Empty<byte>();
        if (i.Sections > 0 && d.Length > expected) trailing = d.AsSpan((int)expected).ToArray();
        return new DtxTemplate(header, i.Bpp, mips, trailing);
    }

    /// <summary>For an image next to its original texture (foo.png / foo.dtx.png beside foo.dtx) returns that texture's template.</summary>
    public static DtxTemplate? FindTemplate(string imagePath)
    {
        try
        {
            string dir = Path.GetDirectoryName(imagePath) ?? "", name = Path.GetFileName(imagePath);
            string dtx = name.EndsWith(".dtx.png", StringComparison.OrdinalIgnoreCase)
                ? name.Substring(0, name.Length - 4)
                : Path.GetFileNameWithoutExtension(name) + ".dtx";
            string cand = Path.Combine(dir, dtx);
            return File.Exists(cand) ? ReadTemplate(File.ReadAllBytes(cand)) : null;
        }
        catch { return null; }
    }

    // ───────────────────────── ENCODE ─────────────────────────
    public static bool HasAlpha(byte[] bgra)
    {
        for (int i = 3; i < bgra.Length; i += 4) if (bgra[i] != 255) return true;
        return false;
    }

    /// <summary>DXT1 when the image is fully opaque, DXT5 when it has transparency.</summary>
    public static int AutoDxt(byte[] bgra) => HasAlpha(bgra) ? BppDxt5 : BppDxt1;

    /// <summary>
    /// Encodes BGRA pixels to a .dtx. bpp: 3 = 32-bit, 4 = DXT1, 5 = DXT3, 6 = DXT5. mips: levels to write (largest first).
    /// With a template the original header (flags, group, command string ...) is kept.
    /// </summary>
    public static byte[] Encode(int w, int h, byte[] bgra, int bpp, int mips, DtxTemplate? tpl = null, Action<string>? warn = null)
    {
        if (w <= 0 || h <= 0 || w > MaxSize || h > MaxSize)
            throw new ArgumentException($"Invalid image size for DTX ({w}x{h}). Maximum is {MaxSize}x{MaxSize}.");
        if (bgra.Length != w * h * 4) throw new ArgumentException("Pixel buffer does not match the image size.");
        if (bpp < Bpp32 || bpp > BppDxt5) throw new NotSupportedException($"Cannot write DTX format '{FormatName(bpp)}'.");

        if (bpp == BppDxt1 && HasAlpha(bgra))
        {
            bpp = BppDxt5;
            warn?.Invoke("The image has transparency but DXT1 cannot store it - DXT5 was used instead.");
        }
        mips = Math.Clamp(mips, 1, MaxMips(w, h));

        if (!IsPow2(w) || !IsPow2(h))
            warn?.Invoke($"Size {w}x{h} is not a power of two - the game may reject or distort this texture.");
        else if (bpp != Bpp32 && (w % 4 != 0 || h % 4 != 0))
            warn?.Invoke($"Size {w}x{h} is not a multiple of 4 - DXT textures normally need that.");

        byte[] trailing = tpl?.Trailing ?? Array.Empty<byte>();
        long total = HeaderSize + ChainBytes(w, h, bpp, mips) + trailing.Length;
        var o = new byte[total];
        WriteHeader(o, w, h, bpp, mips, tpl, trailing.Length > 0);

        int at = HeaderSize;
        byte[] cur = bgra; int cw = w, ch = h;
        for (int m = 0; m < mips; m++)
        {
            if (m > 0) (cur, cw, ch) = Downsample(cur, cw, ch);
            if (bpp == Bpp32) { Buffer.BlockCopy(cur, 0, o, at, cur.Length); at += cur.Length; }
            else at = WriteDxt(cur, cw, ch, bpp, o, at);
        }
        if (trailing.Length > 0) Buffer.BlockCopy(trailing, 0, o, at, trailing.Length);
        return o;
    }

    /// <summary>Header: [24]=texture group, [25]=mipmaps to use, [26]=pixel format. A template keeps every other field.</summary>
    static void WriteHeader(byte[] o, int w, int h, int bpp, int mips, DtxTemplate? tpl, bool keepSections)
    {
        if (tpl is not null) Buffer.BlockCopy(tpl.Header, 0, o, 0, HeaderSize);
        else BitConverter.TryWriteBytes(o.AsSpan(4), -5);

        BitConverter.TryWriteBytes(o.AsSpan(0), 0u);
        BitConverter.TryWriteBytes(o.AsSpan(8), (ushort)w);
        BitConverter.TryWriteBytes(o.AsSpan(10), (ushort)h);
        BitConverter.TryWriteBytes(o.AsSpan(12), (ushort)mips);
        if (!keepSections) BitConverter.TryWriteBytes(o.AsSpan(14), (ushort)0);
        if (tpl is null || o[25] == 0 || o[25] > mips) o[25] = (byte)mips;   // mipmaps to use
        o[26] = (byte)bpp;
    }

    /// <summary>Half-size copy (2x2 box filter, weighted by alpha so transparent pixels do not darken the edges).</summary>
    static (byte[] px, int w, int h) Downsample(byte[] s, int sw, int sh)
    {
        int dw = Math.Max(1, sw >> 1), dh = Math.Max(1, sh >> 1);
        var d = new byte[dw * dh * 4];
        for (int y = 0; y < dh; y++)
        for (int x = 0; x < dw; x++)
        {
            int x0 = Math.Min(x * 2, sw - 1), x1 = Math.Min(x * 2 + 1, sw - 1);
            int y0 = Math.Min(y * 2, sh - 1), y1 = Math.Min(y * 2 + 1, sh - 1);
            int sb = 0, sg = 0, sr = 0, sa = 0;
            for (int k = 0; k < 4; k++)
            {
                int q = ((k < 2 ? y0 : y1) * sw + ((k & 1) == 0 ? x0 : x1)) * 4;
                int a = s[q + 3];
                sb += s[q] * a; sg += s[q + 1] * a; sr += s[q + 2] * a; sa += a;
            }
            int o = (y * dw + x) * 4;
            if (sa > 0)
            {
                d[o] = (byte)((sb + sa / 2) / sa);
                d[o + 1] = (byte)((sg + sa / 2) / sa);
                d[o + 2] = (byte)((sr + sa / 2) / sa);
            }
            d[o + 3] = (byte)((sa + 2) / 4);
        }
        return (d, dw, dh);
    }

    static int WriteDxt(byte[] px, int w, int h, int bpp, byte[] o, int at)
    {
        int bw = (w + 3) / 4, bh = (h + 3) / 4, bs = bpp == BppDxt1 ? 8 : 16;
        if (bw * bh >= 4096)   // big texture: encode block rows in parallel
            Parallel.For(0, bh, by => EncodeBlockRow(px, w, h, bpp, o, at + by * bw * bs, by, bw));
        else
            for (int by = 0; by < bh; by++) EncodeBlockRow(px, w, h, bpp, o, at + by * bw * bs, by, bw);
        return at + bw * bh * bs;
    }

    static void EncodeBlockRow(byte[] px, int w, int h, int bpp, byte[] o, int rowStart, int by, int bw)
    {
        int bs = bpp == BppDxt1 ? 8 : 16;
        Span<byte> blk = stackalloc byte[64];   // 16 pixels x BGRA
        for (int bx = 0; bx < bw; bx++)
        {
            for (int i = 0; i < 16; i++)
            {
                int x = Math.Min(bx * 4 + (i & 3), w - 1), y = Math.Min(by * 4 + (i >> 2), h - 1);
                px.AsSpan((y * w + x) * 4, 4).CopyTo(blk.Slice(i * 4, 4));
            }
            int at = rowStart + bx * bs;
            if (bpp == BppDxt3) { EncodeAlpha4(blk, o, at); at += 8; }
            else if (bpp == BppDxt5) { EncodeAlpha8(blk, o, at); at += 8; }
            EncodeColor(blk, bpp != BppDxt1, o, at);
        }
    }

    // ───────────────────────── colour block ─────────────────────────
    static int To565(int r, int g, int b) => ((r * 31 + 127) / 255 << 11) | ((g * 63 + 127) / 255 << 5) | ((b * 31 + 127) / 255);

    static int Clamp8(double v) => (int)Math.Min(255, Math.Max(0, Math.Round(v)));

    /// <summary>Best (high, low) 5/6-bit endpoint pair that reproduces every 8-bit value through the 2/3 : 1/3 palette entry (flat blocks).</summary>
    static readonly byte[,] Match5 = BuildMatch(5), Match6 = BuildMatch(6);

    static byte[,] BuildMatch(int bits)
    {
        int max = (1 << bits) - 1;
        var e = new int[max + 1];
        for (int i = 0; i <= max; i++) e[i] = bits == 5 ? (i << 3 | i >> 2) : (i << 2 | i >> 4);
        var t = new byte[256, 2];
        for (int v = 0; v < 256; v++)
        {
            int best = int.MaxValue, bh = 0, bl = 0;
            for (int hi = 0; hi <= max; hi++)
            for (int lo = 0; lo <= max; lo++)
            {
                int d = Math.Abs((2 * e[hi] + e[lo]) / 3 - v);
                if (d < best) { best = d; bh = hi; bl = lo; }
            }
            t[v, 0] = (byte)bh; t[v, 1] = (byte)bl;
        }
        return t;
    }

    /// <summary>Nearest-of-4 palette index for every pixel that counts (mask bit set). Needs c0 &gt; c1 for 4-colour mode. Returns the squared error.</summary>
    static long Fit(ReadOnlySpan<byte> px, int mask, int c0, int c1, out uint idx)
    {
        idx = 0;
        Span<byte> pal = stackalloc byte[16];   // R,G,B,_ x 4 (same maths as the decoder)
        Rgb565(c0, pal, 0); Rgb565(c1, pal, 4);
        int n = c0 > c1 ? 4 : 1;                 // c0 == c1: flat block, every pixel uses colour 0
        if (n == 4)
            for (int k = 0; k < 3; k++)
            {
                pal[8 + k] = (byte)((2 * pal[k] + pal[4 + k]) / 3);
                pal[12 + k] = (byte)((pal[k] + 2 * pal[4 + k]) / 3);
            }

        long err = 0;
        for (int i = 0; i < 16; i++)
        {
            if (((mask >> i) & 1) == 0) continue;
            int b = px[i * 4], g = px[i * 4 + 1], r = px[i * 4 + 2], best = 0, bd = int.MaxValue;
            for (int c = 0; c < n; c++)
            {
                int dr = r - pal[c * 4], dg = g - pal[c * 4 + 1], db = b - pal[c * 4 + 2];
                int dist = dr * dr + dg * dg + db * db;
                if (dist < bd) { bd = dist; best = c; }
            }
            err += bd;
            idx |= (uint)best << (2 * i);
        }
        return err;
    }

    static void Consider(ReadOnlySpan<byte> px, int mask, int c0, int c1, ref long bestErr, ref int bestC0, ref int bestC1, ref uint bestIdx)
    {
        if (c0 < c1) { int t = c0; c0 = c1; c1 = t; }   // c0 > c1 selects the 4-colour mode
        long err = Fit(px, mask, c0, c1, out uint idx);
        if (err < bestErr) { bestErr = err; bestC0 = c0; bestC1 = c1; bestIdx = idx; }
    }

    /// <summary>Least squares: given the indices, the endpoints that minimise the error (then rounded to 565).</summary>
    static bool Refine(ReadOnlySpan<byte> px, int mask, uint idx, out int c0, out int c1)
    {
        c0 = c1 = 0;
        double aa = 0, bb = 0, ab = 0;
        double ax0 = 0, ax1 = 0, ax2 = 0, bx0 = 0, bx1 = 0, bx2 = 0;
        for (int i = 0; i < 16; i++)
        {
            if (((mask >> i) & 1) == 0) continue;
            int k = (int)((idx >> (2 * i)) & 3);
            double a = k == 0 ? 1.0 : k == 1 ? 0.0 : k == 2 ? 2.0 / 3.0 : 1.0 / 3.0, b = 1.0 - a;
            double r = px[i * 4 + 2], g = px[i * 4 + 1], bl = px[i * 4];
            aa += a * a; bb += b * b; ab += a * b;
            ax0 += a * r; ax1 += a * g; ax2 += a * bl;
            bx0 += b * r; bx1 += b * g; bx2 += b * bl;
        }
        double det = aa * bb - ab * ab;
        if (Math.Abs(det) < 1e-6) return false;
        c0 = To565(Clamp8((ax0 * bb - bx0 * ab) / det), Clamp8((ax1 * bb - bx1 * ab) / det), Clamp8((ax2 * bb - bx2 * ab) / det));
        c1 = To565(Clamp8((bx0 * aa - ax0 * ab) / det), Clamp8((bx1 * aa - ax1 * ab) / det), Clamp8((bx2 * aa - ax2 * ab) / det));
        return true;
    }

    /// <summary>
    /// Colour block. Candidates: bounding-box diagonal, principal colour axis, exact flat-colour pair; the best one is then refined
    /// by least squares. skipClear: fully transparent pixels are ignored so their hidden colour cannot pollute the visible ones.
    /// </summary>
    static void EncodeColor(ReadOnlySpan<byte> px, bool skipClear, byte[] o, int at)
    {
        int mask = 0xFFFF;
        if (skipClear)
        {
            mask = 0;
            for (int i = 0; i < 16; i++) if (px[i * 4 + 3] != 0) mask |= 1 << i;
            if (mask == 0) { PutColor(o, at, 0, 0, 0u); return; }
        }

        int minR = 255, minG = 255, minB = 255, maxR = 0, maxG = 0, maxB = 0, n = 0, fr = 0, fg = 0, fb = 0;
        double mr = 0, mg = 0, mb = 0;
        bool flat = true;
        for (int i = 0; i < 16; i++)
        {
            if (((mask >> i) & 1) == 0) continue;
            int b = px[i * 4], g = px[i * 4 + 1], r = px[i * 4 + 2];
            if (n == 0) { fr = r; fg = g; fb = b; }
            else if (r != fr || g != fg || b != fb) flat = false;
            n++;
            if (r < minR) minR = r; if (r > maxR) maxR = r;
            if (g < minG) minG = g; if (g > maxG) maxG = g;
            if (b < minB) minB = b; if (b > maxB) maxB = b;
            mr += r; mg += g; mb += b;
        }
        mr /= n; mg /= n; mb /= n;

        long bestErr = long.MaxValue; int bestC0 = 0, bestC1 = 0; uint bestIdx = 0;

        // candidate A: bounding-box diagonal, shrunk a little to lower the error on blocks with outliers
        int ir = (maxR - minR) >> 4, ig = (maxG - minG) >> 4, ib = (maxB - minB) >> 4;
        Consider(px, mask, To565(maxR - ir, maxG - ig, maxB - ib), To565(minR + ir, minG + ig, minB + ib),
                 ref bestErr, ref bestC0, ref bestC1, ref bestIdx);

        // candidate B: principal colour axis (fixes channels that move in opposite directions, and hard edges)
        double crr = 0, cgg = 0, cbb = 0, crg = 0, crb = 0, cgb = 0;
        for (int i = 0; i < 16; i++)
        {
            if (((mask >> i) & 1) == 0) continue;
            double dr = px[i * 4 + 2] - mr, dg = px[i * 4 + 1] - mg, db = px[i * 4] - mb;
            crr += dr * dr; cgg += dg * dg; cbb += db * db;
            crg += dr * dg; crb += dr * db; cgb += dg * db;
        }
        double vr = maxR - minR, vg = maxG - minG, vb = maxB - minB;
        for (int it = 0; it < 4; it++)
        {
            double nr = crr * vr + crg * vg + crb * vb, ng = crg * vr + cgg * vg + cgb * vb, nb = crb * vr + cgb * vg + cbb * vb;
            double len = Math.Sqrt(nr * nr + ng * ng + nb * nb);
            if (len < 1e-9) break;
            vr = nr / len; vg = ng / len; vb = nb / len;
        }
        if (vr * vr + vg * vg + vb * vb > 1e-9)
        {
            double t0 = double.MaxValue, t1 = double.MinValue;
            for (int i = 0; i < 16; i++)
            {
                if (((mask >> i) & 1) == 0) continue;
                double t = (px[i * 4 + 2] - mr) * vr + (px[i * 4 + 1] - mg) * vg + (px[i * 4] - mb) * vb;
                if (t < t0) t0 = t;
                if (t > t1) t1 = t;
            }
            Consider(px, mask,
                     To565(Clamp8(mr + vr * t1), Clamp8(mg + vg * t1), Clamp8(mb + vb * t1)),
                     To565(Clamp8(mr + vr * t0), Clamp8(mg + vg * t0), Clamp8(mb + vb * t0)),
                     ref bestErr, ref bestC0, ref bestC1, ref bestIdx);
        }

        // candidate C: one flat colour -> the endpoint pair whose 2/3 : 1/3 blend lands on it (error <= 1 instead of up to 4)
        if (flat)
            Consider(px, mask,
                     (Match5[fr, 0] << 11) | (Match6[fg, 0] << 5) | Match5[fb, 0],
                     (Match5[fr, 1] << 11) | (Match6[fg, 1] << 5) | Match5[fb, 1],
                     ref bestErr, ref bestC0, ref bestC1, ref bestIdx);

        // least-squares refinement of the winner
        for (int it = 0; it < 3; it++)
        {
            if (!Refine(px, mask, bestIdx, out int r0, out int r1)) break;
            long before = bestErr;
            Consider(px, mask, r0, r1, ref bestErr, ref bestC0, ref bestC1, ref bestIdx);
            if (bestErr >= before) break;
        }

        PutColor(o, at, bestC0, bestC1, bestIdx);
    }

    static void PutColor(byte[] o, int at, int c0, int c1, uint idx)
    {
        o[at] = (byte)c0; o[at + 1] = (byte)(c0 >> 8);
        o[at + 2] = (byte)c1; o[at + 3] = (byte)(c1 >> 8);
        o[at + 4] = (byte)idx; o[at + 5] = (byte)(idx >> 8); o[at + 6] = (byte)(idx >> 16); o[at + 7] = (byte)(idx >> 24);
    }

    // ───────────────────────── alpha blocks ─────────────────────────
    /// <summary>DXT3: explicit 4-bit alpha.</summary>
    static void EncodeAlpha4(ReadOnlySpan<byte> px, byte[] o, int at)
    {
        ulong bits = 0;
        for (int i = 0; i < 16; i++) bits |= (ulong)((px[i * 4 + 3] * 15 + 127) / 255) << (4 * i);
        for (int i = 0; i < 8; i++) o[at + i] = (byte)(bits >> (8 * i));
    }

    static long AlphaFit(ReadOnlySpan<byte> px, int a0, int a1, bool six, out ulong bits)
    {
        Span<int> v = stackalloc int[8];
        v[0] = a0; v[1] = a1;
        if (!six) { for (int k = 2; k < 8; k++) v[k] = ((8 - k) * a0 + (k - 1) * a1) / 7; }
        else
        {
            for (int k = 2; k < 6; k++) v[k] = ((6 - k) * a0 + (k - 1) * a1) / 5;
            v[6] = 0; v[7] = 255;
        }
        bits = 0;
        long err = 0;
        for (int i = 0; i < 16; i++)
        {
            int a = px[i * 4 + 3], best = 0, bd = int.MaxValue;
            for (int k = 0; k < 8; k++)
            {
                int d = Math.Abs(v[k] - a);
                if (d < bd) { bd = d; best = k; }
            }
            err += (long)bd * bd;
            bits |= (ulong)best << (3 * i);
        }
        return err;
    }

    /// <summary>DXT5: tries the 8-value mode (max, min) and the 6-value mode with exact 0 and 255, keeps the lower error.</summary>
    static void EncodeAlpha8(ReadOnlySpan<byte> px, byte[] o, int at)
    {
        int mn = 255, mx = 0, lo = 255, hi = 0;
        for (int i = 0; i < 16; i++)
        {
            int a = px[i * 4 + 3];
            if (a < mn) mn = a;
            if (a > mx) mx = a;
            if (a != 0 && a != 255) { if (a < lo) lo = a; if (a > hi) hi = a; }
        }

        int a0 = mx, a1 = mn;   // a0 > a1 -> 8-value mode (a0 == a1: every pixel uses code 0)
        long err = AlphaFit(px, a0, a1, false, out ulong bits);

        if ((mn == 0 || mx == 255) && hi >= lo && hi > 0)   // block touches 0 or 255 and also has in-between values
        {
            long errB = AlphaFit(px, lo, hi, true, out ulong bitsB);   // a0 <= a1 -> 6-value mode
            if (errB < err) { a0 = lo; a1 = hi; bits = bitsB; }
        }

        o[at] = (byte)a0; o[at + 1] = (byte)a1;
        for (int i = 0; i < 6; i++) o[at + 2 + i] = (byte)(bits >> (8 * i));
    }
}

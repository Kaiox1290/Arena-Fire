using System.Security.Cryptography;

namespace Arena.Core;

public static class Integrity
{
    public static string Sha256(string path)
    {
        using var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read, 1 << 16);
        return Convert.ToHexString(SHA256.HashData(fs)).ToLowerInvariant();
    }

    /// <summary>Offset of the first differing byte, or -1 when both files are identical.</summary>
    public static long FirstDiff(string a, string b)
    {
        using var fa = new FileStream(a, FileMode.Open, FileAccess.Read, FileShare.Read, 1 << 16);
        using var fb = new FileStream(b, FileMode.Open, FileAccess.Read, FileShare.Read, 1 << 16);
        var ba = new byte[1 << 16]; var bb = new byte[1 << 16];
        long off = 0;
        while (true)
        {
            int na = ReadFull(fa, ba), nb = ReadFull(fb, bb), n = Math.Min(na, nb);
            for (int i = 0; i < n; i++) if (ba[i] != bb[i]) return off + i;
            if (na != nb) return off + n;
            if (na == 0) return -1;
            off += na;
        }
    }

    static int ReadFull(Stream s, byte[] buf)
    {
        int t = 0;
        while (t < buf.Length) { int r = s.Read(buf, t, buf.Length - t); if (r == 0) break; t += r; }
        return t;
    }

    /// <summary>Copy of the original into the backup folder (name = first 8 hash chars + file name). The original is never touched.</summary>
    public static string Backup(string src, string backupDir, string? sha256 = null)
    {
        Directory.CreateDirectory(backupDir);
        string dst = Path.Combine(backupDir, $"{(sha256 ?? Sha256(src))[..8]}_{Path.GetFileName(src)}");
        if (!File.Exists(dst)) File.Copy(src, dst);
        return dst;
    }
}

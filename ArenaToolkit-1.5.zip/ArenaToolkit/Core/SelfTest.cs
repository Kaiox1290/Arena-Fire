using System.Text;

namespace Arena.Core;

/// <summary>Built-in checks for the codecs and the REZ packer. Run with:  ArenaTool.exe --selftest</summary>
public static class SelfTest
{
    static byte[] Gradient(int w, int h, bool alpha)
    {
        var p = new byte[w * h * 4];
        for (int y = 0; y < h; y++)
        for (int x = 0; x < w; x++)
        {
            int i = (y * w + x) * 4;
            p[i] = (byte)(x * 255 / (w - 1));
            p[i + 1] = (byte)(y * 255 / (h - 1));
            p[i + 2] = (byte)((x + y) * 127 / (w + h - 2));
            p[i + 3] = (byte)(alpha ? 64 + x * 191 / (w - 1) : 255);
        }
        return p;
    }

    static double Psnr(byte[] a, byte[] b, int firstChannel, int lastChannel)
    {
        double sum = 0; long n = 0;
        for (int i = 0; i < a.Length; i += 4)
            for (int c = firstChannel; c <= lastChannel; c++)
            {
                double d = a[i + c] - b[i + c];
                sum += d * d; n++;
            }
        double mse = sum / Math.Max(1, n);
        return mse == 0 ? 99 : 10 * Math.Log10(255.0 * 255.0 / mse);
    }

    public static string Run()
    {
        var sb = new StringBuilder();
        int fail = 0;

        void Check(string name, Func<string?> body)
        {
            try
            {
                string? r = body();
                if (r is null) sb.AppendLine("PASS   " + name);
                else { fail++; sb.AppendLine("FAIL   " + name + "  -  " + r); }
            }
            catch (Exception ex) { fail++; sb.AppendLine("FAIL   " + name + "  -  " + ex.Message); }
        }

        // ── 32-bit round trip with a mip chain ──
        Check("32-bit encode/decode is lossless, 3 mips", () =>
        {
            var src = Gradient(64, 64, true);
            var dtx = DtxCodec.Encode(64, 64, src, DtxCodec.Bpp32, 3);
            long expect = DtxCodec.HeaderSize + 64 * 64 * 4 + 32 * 32 * 4 + 16 * 16 * 4;
            if (dtx.Length != expect) return $"size {dtx.Length}, expected {expect}";
            var (w, h, px) = DtxCodec.Decode(dtx);
            if (w != 64 || h != 64) return $"decoded {w}x{h}";
            return DtxCodec.SamePixels(src, px) ? null : "pixels differ";
        });

        // ── DXT quality ──
        foreach (var (bpp, alpha) in new[] { (DtxCodec.BppDxt1, false), (DtxCodec.BppDxt3, true), (DtxCodec.BppDxt5, true) })
        {
            int f = bpp;
            bool a = alpha;
            Check($"{DtxCodec.FormatName(f)} quality (gradient 64x64)", () =>
            {
                var src = Gradient(64, 64, a);
                var dtx = DtxCodec.Encode(64, 64, src, f, 1);
                var (_, _, px) = DtxCodec.Decode(dtx);
                double c = Psnr(src, px, 0, 2), al = a ? Psnr(src, px, 3, 3) : 99;
                if (c < 30) return $"colour PSNR {c:0.0} dB (needs 30)";
                if (al < 30) return $"alpha PSNR {al:0.0} dB (needs 30)";
                return null;
            });
        }

        Check("DXT1 flat colour is accurate (max error 2)", () =>
        {
            var src = new byte[16 * 16 * 4];
            for (int i = 0; i < src.Length; i += 4) { src[i] = 30; src[i + 1] = 200; src[i + 2] = 10; src[i + 3] = 255; }
            var (_, _, px) = DtxCodec.Decode(DtxCodec.Encode(16, 16, src, DtxCodec.BppDxt1, 1));
            int worst = 0;
            for (int i = 0; i < px.Length; i += 4)
                for (int c = 0; c < 3; c++) worst = Math.Max(worst, Math.Abs(px[i + c] - src[i + c]));
            return worst <= 2 ? null : $"max error {worst}";
        });

        Check("DXT5 keeps hard cut-out alpha exactly", () =>
        {
            var src = Gradient(32, 32, false);
            for (int y = 0; y < 32; y++)
                for (int x = 0; x < 32; x++) src[(y * 32 + x) * 4 + 3] = (byte)((x / 4 + y / 4) % 2 == 0 ? 255 : 0);
            var (_, _, px) = DtxCodec.Decode(DtxCodec.Encode(32, 32, src, DtxCodec.BppDxt5, 1));
            for (int i = 3; i < src.Length; i += 4) if (px[i] != src[i]) return "alpha changed";
            return null;
        });

        Check("template keeps the original header", () =>
        {
            var src = Gradient(64, 64, true);
            var first = DtxCodec.Encode(64, 64, src, DtxCodec.BppDxt5, 4);
            var tpl = DtxCodec.ReadTemplate(first);
            if (tpl is null) return "template not readable";
            if (tpl.Bpp != DtxCodec.BppDxt5 || tpl.Mips != 4) return $"template says {DtxCodec.FormatName(tpl.Bpp)} / {tpl.Mips} mips";
            var second = DtxCodec.Encode(64, 64, src, tpl.Bpp, tpl.Mips, tpl);
            if (second.Length != first.Length) return "length differs";
            for (int i = 0; i < DtxCodec.HeaderSize; i++) if (first[i] != second[i]) return $"header byte {i} differs";
            return null;
        });

        Check("non power-of-two size produces a warning", () =>
        {
            var msgs = new List<string>();
            DtxCodec.Encode(30, 20, Gradient(30, 20, false), DtxCodec.Bpp32, 1, null, msgs.Add);
            return msgs.Count > 0 ? null : "no warning";
        });

        // ── resize ──
        Check("Lanczos resize keeps a flat colour flat", () =>
        {
            var src = new byte[40 * 30 * 4];
            for (int i = 0; i < src.Length; i += 4) { src[i] = 200; src[i + 1] = 100; src[i + 2] = 50; src[i + 3] = 255; }
            foreach (var (w, h) in new[] { (20, 15), (80, 60), (33, 17) })
            {
                var r = ImageTools.ResizePixels(src, 40, 30, w, h);
                for (int i = 0; i < r.Length; i += 4)
                    if (r[i] != 200 || r[i + 1] != 100 || r[i + 2] != 50 || r[i + 3] != 255) return $"changed at {w}x{h}";
            }
            return null;
        });

        // ── REZ: pack -> open -> extract, plus edited-PNG re-encode ──
        Check("REZ pack/unpack round trip + PNG sync", () =>
        {
            string root = Path.Combine(Path.GetTempPath(), "arena_selftest_" + Guid.NewGuid().ToString("N"));
            try
            {
                string src = Path.Combine(root, "src"), sub = Path.Combine(src, "Tex", "Deep");
                Directory.CreateDirectory(sub);
                File.WriteAllText(Path.Combine(src, "readme.txt"), "hello");
                File.WriteAllBytes(Path.Combine(sub, "data.bin"), new byte[] { 1, 2, 3, 4, 5, 0, 255 });

                var pix = Gradient(32, 32, true);
                byte[] dtxBytes = DtxCodec.Encode(32, 32, pix, DtxCodec.BppDxt5, 2);
                string dtxPath = Path.Combine(sub, "tex.dtx");
                File.WriteAllBytes(dtxPath, dtxBytes);
                var (dw, dh, decoded) = DtxCodec.Decode(dtxBytes);
                ImageTools.SavePng(dw, dh, decoded, Path.Combine(sub, "tex.png"));   // untouched preview next to the texture

                string rez1 = Path.Combine(root, "one.rez");
                RezArchive.Pack(src, rez1, new Job(), CancellationToken.None);
                var a1 = RezArchive.Open(rez1);
                string out1 = Path.Combine(root, "out1");
                a1.ExtractAll(out1, new Job(), CancellationToken.None);

                if (a1.Entries.Count != 3) return $"archive has {a1.Entries.Count} entries, expected 3 (the helper PNG must not be packed)";
                if (File.ReadAllText(Path.Combine(out1, "readme.txt")) != "hello") return "readme.txt differs";
                if (!File.ReadAllBytes(Path.Combine(out1, "Tex", "Deep", "data.bin")).SequenceEqual(new byte[] { 1, 2, 3, 4, 5, 0, 255 })) return "data.bin differs";
                if (!File.ReadAllBytes(Path.Combine(out1, "Tex", "Deep", "tex.dtx")).SequenceEqual(dtxBytes)) return "untouched texture was modified";

                // edit the PNG (paint a red square), pack again
                var edited = (byte[])decoded.Clone();
                for (int y = 8; y < 24; y++)
                    for (int x = 8; x < 24; x++) { int i = (y * 32 + x) * 4; edited[i] = 0; edited[i + 1] = 0; edited[i + 2] = 255; edited[i + 3] = 255; }
                ImageTools.SavePng(32, 32, edited, Path.Combine(sub, "tex.png"));

                var notes = new List<string>();
                string rez2 = Path.Combine(root, "two.rez");
                RezArchive.Pack(src, rez2, new Job(), CancellationToken.None, notes.Add);
                string out2 = Path.Combine(root, "out2");
                RezArchive.Open(rez2).ExtractAll(out2, new Job(), CancellationToken.None);
                byte[] newDtx = File.ReadAllBytes(Path.Combine(out2, "Tex", "Deep", "tex.dtx"));
                if (newDtx.SequenceEqual(dtxBytes)) return "edited PNG was ignored";
                if (newDtx[26] != DtxCodec.BppDxt5 || (newDtx[12] | newDtx[13] << 8) != 2) return "format or mip count not preserved";
                var (_, _, back) = DtxCodec.Decode(newDtx);
                int c = (16 * 32 + 16) * 4;
                if (back[c] > 16 || back[c + 1] > 16 || back[c + 2] < 240) return "edit not visible in the new texture";
                if (notes.Count == 0) return "no note about the re-encode";
                return null;
            }
            finally { try { Directory.Delete(root, true); } catch { } }
        });

        return (fail == 0 ? "All checks passed." : $"{fail} check(s) FAILED.") + Environment.NewLine + Environment.NewLine + sb;
    }
}

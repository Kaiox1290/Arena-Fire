using System.Text.Encodings.Web;
using System.Text.Json;

namespace Arena.Core;

public static class Workspace
{
    public static string Root { get; private set; } = "";
    public static string BackupDir => Path.Combine(Root, "backup");
    public static string LogDir => Path.Combine(Root, "logs");

    public static void Init(string root)
    {
        Directory.CreateDirectory(Path.Combine(root, "backup"));
        Directory.CreateDirectory(Path.Combine(root, "logs"));
        Root = root;
    }
}

/// <summary>Append-only operation log: logs/log.txt</summary>
public static class OpLog
{
    static readonly object G = new();
    public static void Write(string tool, string step, string file, string message)
    {
        try
        {
            if (Workspace.Root.Length == 0) return;
            string line = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] [{tool}] {step,-8} {file} | {message}{Environment.NewLine}";
            lock (G) File.AppendAllText(Path.Combine(Workspace.LogDir, "log.txt"), line);
        }
        catch { /* logging must never crash the tool */ }
    }
}

public sealed record ReportEntry(string File, string Tool, string Status, string? Sha256Before, string? Sha256After,
                                 string Note, DateTime Time, string? Output = null)
{
    public string StatusAr => Status switch
    {
        "success" => "نجح",
        "failed" => "فشل",
        "unsupported" => "غير مدعوم",
        "unverified" => "نجح بدون تحقق (اتجاه واحد / غير مختبر)",
        _ => Status
    };
}

/// <summary>Collects one entry per file and writes logs/report_&lt;session&gt;.json</summary>
public static class ReportHub
{
    static readonly object G = new();
    static readonly List<ReportEntry> All = new();
    static readonly HashSet<string> Batch = new(StringComparer.OrdinalIgnoreCase);
    static readonly string Session = DateTime.Now.ToString("yyyyMMdd_HHmmss");
    static readonly JsonSerializerOptions Opt = new() { WriteIndented = true, Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping };

    public static void BeginBatch() { lock (G) Batch.Clear(); }
    public static bool Has(string file) { lock (G) return Batch.Contains(file); }
    public static void Add(ReportEntry e) { lock (G) { All.Add(e); Batch.Add(e.File); } }
    public static IReadOnlyList<ReportEntry> Snapshot() { lock (G) return All.ToList(); }

    public static string? Flush()
    {
        try
        {
            if (Workspace.Root.Length == 0) return null;
            string path = Path.Combine(Workspace.LogDir, $"report_{Session}.json");
            List<ReportEntry> copy; lock (G) copy = All.ToList();
            var doc = new
            {
                tool = "Team Arena Toolkit",
                generated = DateTime.Now,
                total = copy.Count,
                success = copy.Count(e => e.Status == "success"),
                unverified = copy.Count(e => e.Status == "unverified"),
                failed = copy.Count(e => e.Status == "failed"),
                unsupported = copy.Count(e => e.Status == "unsupported"),
                files = copy
            };
            File.WriteAllText(path, JsonSerializer.Serialize(doc, Opt));
            return path;
        }
        catch { return null; }
    }
}

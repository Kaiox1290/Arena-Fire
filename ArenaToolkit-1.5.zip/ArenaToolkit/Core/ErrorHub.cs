using System.Runtime.InteropServices;
using System.Text;

namespace Arena.Core;

public sealed record ArenaError(string Code, string Area, string Message, string Hint,
                                 string Detail, DateTime Time, string? File);

/// <summary>Central error reporting: classify -> friendly message + hint + code -> log file -> UI event.</summary>
public static class ErrorHub
{
    static readonly object Gate = new();
    static string lastKey = "";
    static DateTime lastAt = DateTime.MinValue;

    public static string LogDir { get; } = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "TeamArena", "logs");

    public static event Action<ArenaError>? Raised;

    static ErrorHub()
    {
        try { Directory.CreateDirectory(LogDir); Prune(); } catch { }
    }

    public static ArenaError Report(Exception ex, string area, string? file = null, bool silent = false)
    {
        if (ex is AggregateException ag && ag.InnerExceptions.Count > 0)
            ex = ag.Flatten().InnerExceptions[0];

        var (kind, msg, hint) = Classify(ex);
        var err = new ArenaError($"ARN-{area.ToUpperInvariant()}-{kind}", area, msg, hint,
                                  ex.ToString(), DateTime.Now, file);
        WriteLog(err);
        // Same error twice within 2 s is logged but not shown again (prevents toast / dialog loops).
        if (!silent && !IsRepeat(err)) Raised?.Invoke(err);
        return err;
    }

    /// <summary>A finished job that needs the user's attention (not a failure): logged, returned for the "Details" panel, never raised on its own.</summary>
    public static ArenaError Warn(string area, string message, string detail, string? file = null)
    {
        var err = new ArenaError($"ARN-{area.ToUpperInvariant()}-WARN", area, message,
                                  "The job finished, but some things need your attention.", detail, DateTime.Now, file);
        WriteLog(err);
        return err;
    }

    static bool IsRepeat(ArenaError e)
    {
        lock (Gate)
        {
            string key = e.Code + "|" + e.Message;
            var now = DateTime.UtcNow;
            bool repeat = key == lastKey && (now - lastAt).TotalSeconds < 2;
            lastKey = key; lastAt = now;
            return repeat;
        }
    }

    static (string kind, string msg, string hint) Classify(Exception ex) => ex switch
    {
        OperationCanceledException => ("CANCEL", "Operation cancelled.", "Nothing was changed."),
        ToolConfigException => ("CFG", ex.Message, "Open config.json, fix the tool path / args, then drop the file again."),
        ExternalToolException => ("EXT", ex.Message, "The external tool failed. Its output is in logs/log.txt. Check the tool's command line in config.json."),
        RoundTripException => ("ROUNDTRIP", ex.Message, "The conversion was NOT trusted and its output was removed. Do not use this converter on this file until the difference is understood."),
        InvalidDataException => ("DATA", ex.Message, "The file is corrupted, encrypted, or not the expected format."),
        NotSupportedException => ("FMT", ex.Message, "This variant is not supported yet."),
        UnauthorizedAccessException => ("ACCESS", "Access denied.", "Close any program using the file, or run as Administrator."),
        FileNotFoundException or DirectoryNotFoundException => ("NOTFOUND", "File or folder not found.", "It was moved or deleted. Add it again."),
        EndOfStreamException => ("DATA", "The file ended unexpectedly.", "The file is truncated or corrupted."),
        PathTooLongException => ("PATH", "The path is too long.", "Move the file closer to the drive root or shorten its name."),
        IOException => ("IO", ex.Message, "Disk full, or the file is locked by another program."),
        OutOfMemoryException => ("MEM", "Out of memory.", "Process fewer/smaller files at once."),
        ExternalException => ("IMG", "The image engine failed: " + ex.Message, "The file may be corrupted, or the output path is locked."),
        ArgumentException => ("ARG", ex.Message, "Check the values you entered."),
        _ => ("UNK", ex.Message, "Unexpected error. Use 'Copy report' and send it to Team Arena.")
    };

    static void WriteLog(ArenaError e)
    {
        try
        {
            var sb = new StringBuilder()
                .AppendLine($"[{e.Time:yyyy-MM-dd HH:mm:ss}] {e.Code}  file={e.File ?? "-"}")
                .AppendLine(e.Message).AppendLine(e.Detail).AppendLine(new string('-', 70));
            lock (Gate) File.AppendAllText(Path.Combine(LogDir, $"{DateTime.Now:yyyy-MM-dd}.log"), sb.ToString());
        }
        catch { /* logging must never crash the app */ }
    }

    /// <summary>Keep the log folder small: delete logs older than 14 days.</summary>
    static void Prune()
    {
        foreach (var f in Directory.EnumerateFiles(LogDir, "*.log"))
        {
            try { if (File.GetLastWriteTime(f) < DateTime.Now.AddDays(-14)) File.Delete(f); } catch { }
        }
    }
}

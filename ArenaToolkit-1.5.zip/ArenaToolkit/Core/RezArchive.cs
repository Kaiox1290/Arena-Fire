using System.Buffers;
using System.Collections.Concurrent;
using System.Security.Cryptography;
using System.Text;

namespace Arena.Core;

public sealed record RezEntry(string Path, uint Pos, uint Size, uint Id);

/// <summary>LithTech REZ (v1 layout) reader / writer. Extraction is parallel; packing is atomic.</summary>
public sealed class RezArchive
{
    public string FilePath { get; }
    public List<RezEntry> Entries { get; } = new();
    public long TotalBytes => Entries.Sum(e => (long)e.Size);
    readonly HashSet<(uint, uint)> seenDirs = new();
    RezArchive(string path) => FilePath = path;

    // ───────────────────────── READ ─────────────────────────
    public static RezArchive Open(string path)
    {
        var a = new RezArchive(path);
        using var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read, 1 << 16);
        var head = new byte[(int)Math.Min(512, fs.Length)];
        fs.ReadExactly(head);
        int mark = Array.IndexOf(head, (byte)0x1A);
        if (mark < 0 || Encoding.Latin1.GetString(head, 0, mark).IndexOf("LithTech", StringComparison.OrdinalIgnoreCase) < 0)
            throw new InvalidDataException("Not a LithTech REZ archive (signature not found). Encrypted or modified variants are not supported.");

        fs.Position = mark + 1;
        using var br = new BinaryReader(fs, Encoding.Latin1, true);
        br.ReadUInt32(); // format version
        uint rootPos = br.ReadUInt32(), rootSize = br.ReadUInt32();
        if (rootPos == 0 || (long)rootPos + rootSize > fs.Length)
            throw new InvalidDataException("Corrupted REZ header: directory table is outside the file.");
        fs.Position = rootPos;
        uint firstType = br.ReadUInt32();
        if (firstType > 1)   // plain layout starts with entry type 0 (file) or 1 (folder); anything else = scrambled table
            throw new InvalidDataException("This REZ has an encrypted directory table (real-client layout) that the built-in reader does not handle. " +
                                           "Run setup.bat and rebuild: the tool then reads and writes it through CF Rez Manager.");
        a.ReadDir(br, rootPos, rootSize, "", 0);
        return a;
    }

    void ReadDir(BinaryReader br, uint pos, uint size, string prefix, int depth)
    {
        if (depth > 32) throw new InvalidDataException("REZ directory nesting is too deep (corrupted?).");
        if (!seenDirs.Add((pos, size))) throw new InvalidDataException("REZ directory points back to itself (corrupted?).");
        br.BaseStream.Position = pos;
        long end = (long)pos + size;
        var subs = new List<(string name, uint pos, uint size)>();

        while (br.BaseStream.Position < end)
        {
            long at = br.BaseStream.Position;
            uint type = br.ReadUInt32(), p = br.ReadUInt32(), s = br.ReadUInt32();
            br.ReadUInt32(); // time
            if (type == 1)
            {
                subs.Add((ReadStr(br), p, s));
            }
            else if (type == 0)
            {
                uint id = br.ReadUInt32();
                var t = br.ReadBytes(4); Array.Reverse(t);
                string ext = Encoding.Latin1.GetString(t).Trim('\0', ' ');
                uint keys = br.ReadUInt32();
                string name = ReadStr(br);
                ReadStr(br); // description
                br.BaseStream.Position += 4L * keys;
                Entries.Add(new RezEntry(prefix + name + (ext.Length > 0 ? "." + ext : ""), p, s, id));
            }
            else throw new InvalidDataException($"Unknown REZ entry type {type} at 0x{at:X}.");
        }
        foreach (var d in subs) ReadDir(br, d.pos, d.size, prefix + d.name + "/", depth + 1);
    }

    static string ReadStr(BinaryReader br)
    {
        var sb = new StringBuilder();
        for (int i = 0; i < 4096; i++)
        {
            byte b = br.ReadByte();
            if (b == 0) return sb.ToString();
            sb.Append((char)b);
        }
        throw new InvalidDataException("REZ string is too long (corrupted?).");
    }

    // ───────────────────────── EXTRACT ─────────────────────────
    public void ExtractAll(string outDir, Job job, CancellationToken ct)
    {
        string root = Path.TrimEndingDirectorySeparator(Path.GetFullPath(outDir));
        Directory.CreateDirectory(root);
        job.Add(Entries.Count);
        var bad = new ConcurrentBag<string>();
        var opt = new ParallelOptions { CancellationToken = ct, MaxDegreeOfParallelism = Math.Max(2, Environment.ProcessorCount) };

        // One destination per entry, decided up front: two entries with the same name can never overwrite each other.
        var plan = new List<(RezEntry e, string dest)>(Entries.Count);
        var used = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var en in Entries)
        {
            try
            {
                string dest = SafePath(root, en.Path), u = dest;
                for (int i = 2; !used.Add(u); i++)
                    u = Path.Combine(Path.GetDirectoryName(dest)!, Path.GetFileNameWithoutExtension(dest) + "_" + i + Path.GetExtension(dest));
                plan.Add((en, u));
            }
            catch (Exception ex)
            {
                bad.Add($"{en.Path}: {ex.Message}");
                job.Tick();
            }
        }

        Parallel.ForEach(plan, opt,
            () => new FileStream(FilePath, FileMode.Open, FileAccess.Read, FileShare.Read, 1 << 16),
            (item, _, _, fs) =>
            {
                var buf = ArrayPool<byte>.Shared.Rent(1 << 17);
                string dest = item.dest;
                try
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(dest)!);
                    if ((long)item.e.Pos + item.e.Size > fs.Length)
                        throw new InvalidDataException($"'{item.e.Path}' points outside the archive.");
                    fs.Position = item.e.Pos;
                    using (var o = new FileStream(dest, FileMode.Create, FileAccess.Write, FileShare.None, 1 << 16))
                    {
                        long left = item.e.Size;
                        while (left > 0)
                        {
                            int n = fs.Read(buf, 0, (int)Math.Min(buf.Length, left));
                            if (n <= 0) throw new EndOfStreamException();
                            o.Write(buf, 0, n);
                            left -= n;
                        }
                    }
                }
                catch (Exception ex) when (ex is not OperationCanceledException)
                {
                    bad.Add($"{item.e.Path}: {ex.Message}");
                    try { File.Delete(dest); } catch { }   // never leave a half-written file behind
                }
                finally { ArrayPool<byte>.Shared.Return(buf); }
                job.Tick();
                return fs;
            },
            fs => fs.Dispose());

        if (!bad.IsEmpty)
            throw new InvalidDataException($"{bad.Count} of {Entries.Count} entries failed. First: {bad.First()}");
    }

    static string SafePath(string root, string rel)
    {
        var parts = rel.Split('/', '\\').Select(Clean).Where(s => s.Length > 0).ToList();
        string p = Path.GetFullPath(Path.Combine(new[] { root }.Concat(parts).ToArray()));
        if (!p.StartsWith(root + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("Blocked unsafe path: " + rel);
        return p;
    }

    static readonly HashSet<string> DeviceNames = new(StringComparer.OrdinalIgnoreCase)
    {
        "CON", "PRN", "AUX", "NUL",
        "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9",
        "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9"
    };

    static string Clean(string s)
    {
        if (s.Length == 0) return "";
        if (s is "." or "..") return "_";
        foreach (var c in Path.GetInvalidFileNameChars()) s = s.Replace(c, '_');
        s = s.Trim().TrimEnd('.');   // Windows silently drops trailing dots / spaces
        if (s.Length == 0) return "_";
        int dot = s.IndexOf('.');
        if (DeviceNames.Contains(dot < 0 ? s : s.Substring(0, dot))) s = "_" + s;   // CON, NUL, COM1 ... cannot be file names
        return s;
    }

    // ───────────────────────── PACK ─────────────────────────
    sealed class Node { public string Name = ""; public SortedDictionary<string, Node> Dirs = new(StringComparer.OrdinalIgnoreCase); public List<Rec> Files = new(); }
    sealed class Rec { public string Name = "", Ext = "", Full = "", Rel = ""; public byte[]? Data; public uint Pos, Size; }

    /// <summary>Files that must never go into an archive: OS junk, temp files, and the backups the Config editor leaves.</summary>
    static bool IsJunk(string f)
    {
        string n = Path.GetFileName(f);
        if (n.Equals("Thumbs.db", StringComparison.OrdinalIgnoreCase) ||
            n.Equals("desktop.ini", StringComparison.OrdinalIgnoreCase) ||
            n.Equals(".DS_Store", StringComparison.OrdinalIgnoreCase)) return true;
        if (n.EndsWith(".arn_tmp", StringComparison.OrdinalIgnoreCase)) return true;
        return n.EndsWith(".bak", StringComparison.OrdinalIgnoreCase) && File.Exists(f.Substring(0, f.Length - 4));
    }

    /// <summary>
    /// For a .dtx that has its PNG next to it (foo.dtx.png, or foo.png): if the picture was edited, the texture is re-encoded from it
    /// (same format, header and mip count as the original); if not, the original bytes are kept. The helper PNG is never packed.
    /// </summary>
    static void Inspect(string folder, string dtx, HashSet<string> files, ConcurrentDictionary<string, byte[]> replace,
                        ConcurrentBag<string> skip, Action<string>? warn)
    {
        string rel = Path.GetRelativePath(folder, dtx);
        string explicitPng = dtx + ".png", implicitPng = Path.ChangeExtension(dtx, ".png");
        bool isExplicit = files.Contains(explicitPng);
        string? png = isExplicit ? explicitPng : files.Contains(implicitPng) ? implicitPng : null;
        if (png is null) return;

        byte[] bytes = File.ReadAllBytes(dtx);
        DtxInfo info;
        try { info = DtxCodec.ReadInfo(bytes); }
        catch (InvalidDataException) { return; }   // not a real texture: pack both as plain files

        int pw, ph; byte[] ppx;
        try { (pw, ph, ppx) = ImageTools.LoadBgra(png); }
        catch (InvalidDataException) { return; }   // not a readable image: pack both as plain files
        if (!isExplicit && (pw != info.Width || ph != info.Height)) return;   // an unrelated image that only shares the name

        bool same;
        try
        {
            var (dw, dh, dpx) = DtxCodec.Decode(bytes);
            same = dw == pw && dh == ph && DtxCodec.SamePixels(dpx, ppx);
        }
        catch (Exception ex) when (ex is NotSupportedException or InvalidDataException)
        {
            skip.Add(png);
            warn?.Invoke($"{rel}: this texture format cannot be re-encoded - the original .dtx was packed, the image next to it was ignored.");
            return;
        }

        skip.Add(png);
        if (same) return;

        var tpl = DtxCodec.ReadTemplate(bytes);
        if (tpl is null)
        {
            warn?.Invoke($"{rel}: this texture format cannot be re-encoded - the original .dtx was packed, the edited image was ignored.");
            return;
        }
        byte[] data = DtxCodec.Encode(pw, ph, ppx, tpl.Bpp, tpl.Mips, tpl, m => warn?.Invoke($"{rel}: {m}"));
        replace[dtx] = data;
        int mipCount = data[12] | (data[13] << 8);
        warn?.Invoke($"{rel}: re-encoded from the edited image  ({DtxCodec.FormatName(data[26])}, {mipCount} mip)");
    }

    public static void Pack(string folder, string outFile, Job job, CancellationToken ct, Action<string>? warn = null)
    {
        folder = Path.GetFullPath(folder);
        var files = Directory.GetFiles(folder, "*", SearchOption.AllDirectories).Where(f => !IsJunk(f)).ToArray();
        if (files.Length == 0) throw new InvalidDataException("The folder is empty (nothing to pack).");
        job.Add(files.Length + 1);

        // textures edited through their PNG are re-encoded first
        var replace = new ConcurrentDictionary<string, byte[]>(StringComparer.OrdinalIgnoreCase);
        var skip = new ConcurrentBag<string>();
        var set = new HashSet<string>(files, StringComparer.OrdinalIgnoreCase);
        var opt = new ParallelOptions { CancellationToken = ct, MaxDegreeOfParallelism = Math.Max(2, Environment.ProcessorCount) };
        Parallel.ForEach(files.Where(f => f.EndsWith(".dtx", StringComparison.OrdinalIgnoreCase)), opt,
                         f => Inspect(folder, f, set, replace, skip, warn));
        var skipSet = new HashSet<string>(skip, StringComparer.OrdinalIgnoreCase);

        var rootNode = new Node();
        var all = new List<Rec>();
        foreach (var f in files)
        {
            if (skipSet.Contains(f)) { job.Tick(); continue; }
            var rel = Path.GetRelativePath(folder, f).Split(Path.DirectorySeparatorChar);
            if (rel.Any(part => part.Any(ch => ch > 255)))
                throw new InvalidDataException($"'{Path.GetRelativePath(folder, f)}' has characters REZ cannot store (Latin-1 only). Rename it and try again.");
            var n = rootNode;
            for (int i = 0; i < rel.Length - 1; i++)
            {
                if (!n.Dirs.TryGetValue(rel[i], out var c)) n.Dirs[rel[i]] = c = new Node { Name = rel[i] };
                n = c;
            }
            string fn = rel[^1], ext = Path.GetExtension(fn).TrimStart('.'), name = Path.GetFileNameWithoutExtension(fn);
            if (ext.Length > 4) { name = fn; ext = ""; }
            var r = new Rec { Name = name, Ext = ext, Full = f, Rel = string.Join('/', rel) };
            if (replace.TryGetValue(f, out var data)) r.Data = data;
            n.Files.Add(r); all.Add(r);
        }
        if (all.Count == 0) throw new InvalidDataException("Nothing to pack.");

        string outFull = Path.GetFullPath(outFile);
        Directory.CreateDirectory(Path.GetDirectoryName(outFull)!);
        Atomic.Write(outFull, tmp => { WriteArchive(tmp, rootNode, all, job, ct); VerifyWritten(tmp, all, ct); });   // a failed check deletes the temp file; an older output is never replaced by a bad one
        job.Tick();
    }

    /// <summary>
    /// Copies <paramref name="folder"/> into a new temp folder the way Pack would pack it: junk and helper PNGs left out,
    /// textures edited through their PNG re-encoded. Used when another packer writes the archive. The caller deletes the folder.
    /// </summary>
    public static string Stage(string folder, Job job, CancellationToken ct, Action<string>? warn = null)
    {
        folder = Path.GetFullPath(folder);
        var files = Directory.GetFiles(folder, "*", SearchOption.AllDirectories).Where(f => !IsJunk(f)).ToArray();
        if (files.Length == 0) throw new InvalidDataException("The folder is empty (nothing to pack).");
        job.Add(files.Length);

        var replace = new ConcurrentDictionary<string, byte[]>(StringComparer.OrdinalIgnoreCase);
        var skip = new ConcurrentBag<string>();
        var set = new HashSet<string>(files, StringComparer.OrdinalIgnoreCase);
        var opt = new ParallelOptions { CancellationToken = ct, MaxDegreeOfParallelism = Math.Max(2, Environment.ProcessorCount) };
        Parallel.ForEach(files.Where(f => f.EndsWith(".dtx", StringComparison.OrdinalIgnoreCase)), opt,
                         f => Inspect(folder, f, set, replace, skip, warn));
        var skipSet = new HashSet<string>(skip, StringComparer.OrdinalIgnoreCase);

        string stage = Path.Combine(Path.GetTempPath(), "arena_stage_" + Guid.NewGuid().ToString("N"));
        try
        {
            foreach (var f in files)
            {
                ct.ThrowIfCancellationRequested();
                if (skipSet.Contains(f)) { job.Tick(); continue; }
                string dst = Path.Combine(stage, Path.GetRelativePath(folder, f));
                Directory.CreateDirectory(Path.GetDirectoryName(dst)!);
                if (replace.TryGetValue(f, out var data)) File.WriteAllBytes(dst, data); else File.Copy(f, dst);
                job.Tick();
            }
            return stage;
        }
        catch { try { Directory.Delete(stage, true); } catch { } throw; }
    }

    /// <summary>Re-opens the freshly written archive and compares entry list, sizes and per-entry SHA-256 with what was packed.</summary>
    static void VerifyWritten(string archivePath, List<Rec> all, CancellationToken ct)
    {
        var a = Open(archivePath);
        if (a.Entries.Count != all.Count)
            throw new InvalidDataException($"Pack verification failed: the archive lists {a.Entries.Count} entries but {all.Count} were packed.");
        var expected = new Dictionary<string, Rec>(StringComparer.OrdinalIgnoreCase);
        foreach (var r in all)
            if (!expected.TryAdd(r.Rel, r)) throw new InvalidDataException($"Pack verification failed: duplicate path '{r.Rel}'.");

        using var fs = new FileStream(archivePath, FileMode.Open, FileAccess.Read, FileShare.Read, 1 << 16);
        var buf = new byte[1 << 16];
        foreach (var e in a.Entries)
        {
            ct.ThrowIfCancellationRequested();
            if (!expected.TryGetValue(e.Path, out var r))
                throw new InvalidDataException($"Pack verification failed: '{e.Path}' is in the archive but was not packed.");
            long want = r.Data?.Length ?? new FileInfo(r.Full).Length;
            if (e.Size != want || (long)e.Pos + e.Size > fs.Length)
                throw new InvalidDataException($"Pack verification failed: size/offset of '{e.Path}' is wrong ({e.Size} vs {want}).");

            using var h = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
            fs.Position = e.Pos;
            for (long left = e.Size; left > 0;)
            {
                int n = fs.Read(buf, 0, (int)Math.Min(buf.Length, left));
                if (n <= 0) throw new EndOfStreamException();
                h.AppendData(buf, 0, n); left -= n;
            }
            byte[] got = h.GetHashAndReset(), exp;
            if (r.Data is not null) exp = SHA256.HashData(r.Data);
            else { using var sf = new FileStream(r.Full, FileMode.Open, FileAccess.Read, FileShare.Read, 1 << 16); exp = SHA256.HashData(sf); }
            if (!got.AsSpan().SequenceEqual(exp))
                throw new InvalidDataException($"Pack verification failed: content of '{e.Path}' differs from what was packed.");
        }
    }

    static void WriteArchive(string target, Node rootNode, List<Rec> all, Job job, CancellationToken ct)
    {
        using var fs = new FileStream(target, FileMode.Create, FileAccess.Write, FileShare.None, 1 << 16);
        using var bw = new BinaryWriter(fs, Encoding.Latin1);
        bw.Write(Encoding.Latin1.GetBytes("\r\n*** LithTech Resource File ***\r\nPacked with Team Arena Toolkit\r\n\u001a"));
        long hdr = fs.Position;
        for (int i = 0; i < 10; i++) bw.Write(0u);
        bw.Write((byte)0);
        uint now = (uint)DateTimeOffset.UtcNow.ToUnixTimeSeconds();

        foreach (var r in all)
        {
            ct.ThrowIfCancellationRequested();
            if (r.Data is not null)
            {
                if (fs.Position + r.Data.Length > uint.MaxValue) throw new NotSupportedException("REZ v1 is limited to 4 GB.");
                r.Pos = (uint)fs.Position;
                fs.Write(r.Data, 0, r.Data.Length);
                r.Size = (uint)r.Data.Length;
            }
            else
            {
                using var src = new FileStream(r.Full, FileMode.Open, FileAccess.Read, FileShare.Read, 1 << 16);
                if (fs.Position + src.Length > uint.MaxValue) throw new NotSupportedException("REZ v1 is limited to 4 GB.");
                r.Pos = (uint)fs.Position;
                src.CopyTo(fs);
                r.Size = (uint)src.Length;
            }
            job.Tick();
        }

        uint idc = 1;
        void WriteStr(string s) { bw.Write(Encoding.Latin1.GetBytes(s)); bw.Write((byte)0); }
        (uint pos, uint size) WriteDir(Node n)
        {
            var kids = n.Dirs.Values.Select(d => (d, WriteDir(d))).ToList(); // children first
            uint start = (uint)fs.Position;
            foreach (var (d, (p, s)) in kids) { bw.Write(1u); bw.Write(p); bw.Write(s); bw.Write(now); WriteStr(d.Name); }
            foreach (var f in n.Files)
            {
                bw.Write(0u); bw.Write(f.Pos); bw.Write(f.Size); bw.Write(now); bw.Write(idc++);
                var t = new byte[4]; var eb = Encoding.Latin1.GetBytes(f.Ext); Array.Copy(eb, t, Math.Min(4, eb.Length)); Array.Reverse(t);
                bw.Write(t); bw.Write(0u); WriteStr(f.Name); WriteStr("");
            }
            return (start, (uint)fs.Position - start);
        }

        var root = WriteDir(rootNode);
        uint end = (uint)fs.Position;
        fs.Position = hdr;
        bw.Write(1u); bw.Write(root.pos); bw.Write(root.size); bw.Write(now); bw.Write(end); bw.Write(now);
        bw.Write(0u); bw.Write(256u); bw.Write((uint)all.Max(f => f.Name.Length + 1)); bw.Write(0u);
        bw.Flush();
    }
}

using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;

namespace Arena.Core;

public static class IconExtractor
{
    [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
    static extern uint ExtractIconEx(string file, int index, IntPtr[]? large, IntPtr[]? small, uint n);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    static extern uint PrivateExtractIcons(string file, int index, int cx, int cy, IntPtr[] icons, int[] ids, uint n, uint flags);
    [DllImport("user32.dll")]
    static extern bool DestroyIcon(IntPtr h);

    static readonly int[] IcoSizes = { 256, 64, 48, 32, 16 };

    public static int Count(string file) => (int)ExtractIconEx(file, -1, null, null, 0);

    /// <summary>Loads icon number <paramref name="index"/> at the requested size (null when the file has no such image).</summary>
    static Bitmap? Load(string file, int index, int size, bool fallback)
    {
        var h = new IntPtr[1];
        uint got = PrivateExtractIcons(file, index, size, size, h, new int[1], 1, 0);
        if ((got == 0 || got == uint.MaxValue || h[0] == IntPtr.Zero) && fallback)
        {
            h = new IntPtr[1];
            ExtractIconEx(file, index, h, null, 1);
        }
        if (h[0] == IntPtr.Zero) return null;
        try
        {
            using var ic = Icon.FromHandle(h[0]);
            return ic.ToBitmap();
        }
        catch { return null; }
        finally { DestroyIcon(h[0]); }
    }

    /// <summary>Every icon is saved as icon_000.png (largest image) and icon_000.ico (all available sizes, PNG-compressed).</summary>
    public static int ExtractAll(string file, string outDir, Job job, CancellationToken ct)
    {
        int n = Count(file), saved = 0;
        if (n <= 0) throw new InvalidDataException("No icons found in this file.");
        Directory.CreateDirectory(outDir);
        job.Add(n);

        for (int i = 0; i < n; i++)
        {
            ct.ThrowIfCancellationRequested();
            using (var big = Load(file, i, 256, true))
            {
                if (big is not null)
                {
                    Atomic.Write(Path.Combine(outDir, $"icon_{i:000}.png"), tmp => big.Save(tmp, ImageFormat.Png));
                    saved++;
                    try { SaveIco(file, i, big, Path.Combine(outDir, $"icon_{i:000}.ico")); }
                    catch (Exception ex) when (ex is not OperationCanceledException) { ErrorHub.Report(ex, "ICON", file, true); }
                }
            }
            job.Tick();
        }
        if (saved == 0) throw new InvalidDataException("Icons were found but none could be extracted.");
        return saved;
    }

    static byte[] Png(Bitmap b)
    {
        using var ms = new MemoryStream();
        b.Save(ms, ImageFormat.Png);
        return ms.ToArray();
    }

    /// <summary>Multi-size .ico: the largest image already loaded plus the smaller sizes the file offers (duplicates are skipped).</summary>
    static void SaveIco(string file, int index, Bitmap largest, string path)
    {
        var imgs = new List<(int size, byte[] png)>();
        var seen = new HashSet<int>();
        if (largest.Width == largest.Height && largest.Width <= 256) { seen.Add(largest.Width); imgs.Add((largest.Width, Png(largest))); }

        foreach (int size in IcoSizes)
        {
            if (seen.Contains(size)) continue;
            using var b = Load(file, index, size, false);
            if (b is null || b.Width != b.Height || b.Width > 256 || !seen.Add(b.Width)) continue;
            imgs.Add((b.Width, Png(b)));
        }
        if (imgs.Count == 0) return;
        imgs.Sort((a, b) => b.size.CompareTo(a.size));

        Atomic.Write(path, tmp =>
        {
            using var fs = new FileStream(tmp, FileMode.Create, FileAccess.Write);
            using var bw = new BinaryWriter(fs);
            bw.Write((ushort)0); bw.Write((ushort)1); bw.Write((ushort)imgs.Count);
            int offset = 6 + 16 * imgs.Count;
            foreach (var im in imgs)
            {
                byte dim = (byte)(im.size >= 256 ? 0 : im.size);   // 0 means 256
                bw.Write(dim); bw.Write(dim); bw.Write((byte)0); bw.Write((byte)0);
                bw.Write((ushort)1); bw.Write((ushort)32);
                bw.Write((uint)im.png.Length); bw.Write((uint)offset);
                offset += im.png.Length;
            }
            foreach (var im in imgs) bw.Write(im.png);
        });
    }
}

namespace Arena.Core;

/// <param name="ReverseKey">Tool that converts back; null + OneWay = no round trip possible.</param>
/// <param name="OutExt">Empty = keep the input extension.</param>
public sealed record ConvSpec(string Title, string Tool, string ForwardKey, string? ReverseKey, string OutExt,
                              bool OneWay = false, string? RequiredArg = null);

/// <summary>hash → backup → convert (external tool) → convert back → compare SHA-256 → report. Any problem stops with a detailed error.</summary>
public static class Pipeline
{
    public static ReportEntry Convert(ArenaConfig cfg, ConvSpec spec, string input, string outDir, string backupDir, CancellationToken ct)
    {
        string name = Path.GetFileName(input);
        string before = Integrity.Sha256(input);
        string? after = null, outFile = null;
        ExternalToolCfg? rev = null;      // declared here so the failure handlers know whether a verified result was required
        try
        {
            ct.ThrowIfCancellationRequested();
            OpLog.Write(spec.Tool, "start", name, $"{spec.Title}; sha256={before}");

            // 1. backup (original is never modified)
            OpLog.Write(spec.Tool, "backup", name, Integrity.Backup(input, backupDir, before));

            if (input.EndsWith(".csv", StringComparison.OrdinalIgnoreCase))
                OpLog.Write(spec.Tool, "csv-in", name, CsvAnalyzer.Analyze(input).Summary);   // encoding read from the file itself

            // 2. check everything BEFORE running anything
            var fwd = cfg.Require(spec.ForwardKey, spec.RequiredArg);
            if (!spec.OneWay)
            {
                if (spec.ReverseKey is null) throw new ToolConfigException($"{spec.Title}: no reverse converter defined, cannot verify.");
                if (cfg.IsConfigured(spec.ReverseKey)) rev = cfg.Require(spec.ReverseKey);
                else if (cfg.RequireRoundTrip)
                    throw new ToolConfigException($"{spec.Title}: round-trip check needs Tools.{spec.ReverseKey} in config.json (RequireRoundTrip is true). Nothing was converted.");
            }

            // 3. forward
            string ext = spec.OutExt.Length > 0 ? spec.OutExt : Path.GetExtension(name);
            outFile = Unique(Path.Combine(outDir, Path.GetFileNameWithoutExtension(name) + ext));
            string log = ExternalRunner.Run(spec.ForwardKey, fwd, input, outFile, ct);
            OpLog.Write(spec.Tool, "convert", name, $"-> {outFile} | tool says: {Short(log)}");

            // 4. round trip: original -> converted -> back, SHA-256 must match the original
            if (rev is not null)
            {
                string tmp = Path.Combine(Path.GetTempPath(), "arena_rt_" + Guid.NewGuid().ToString("N"));
                Directory.CreateDirectory(tmp);
                try
                {
                    string back = Path.Combine(tmp, name);
                    ExternalRunner.Run(spec.ReverseKey!, rev, outFile, back, ct);
                    after = Integrity.Sha256(back);
                    long diff = Integrity.FirstDiff(input, back);
                    if (diff >= 0)
                        throw new RoundTripException(
                            $"Round-trip FAILED for '{name}': first different byte at offset {diff} (0x{diff:X}). " +
                            $"original sha256={before}, after sha256={after}. The converted file was removed.", diff);
                }
                finally { try { Directory.Delete(tmp, true); } catch { } }
                OpLog.Write(spec.Tool, "verify", name, $"round-trip OK, sha256 identical ({before})");
            }

            // 5. CSV: report encoding / layout read from the file itself
            string note = rev is null ? "one-way conversion: round-trip is not possible, result NOT verified"
                                      : "round-trip OK: SHA-256 identical to the original";
            if (outFile.EndsWith(".csv", StringComparison.OrdinalIgnoreCase))
            {
                string csv = CsvAnalyzer.Analyze(outFile).Summary;
                OpLog.Write(spec.Tool, "csv", name, csv);
                note += " | " + csv;
            }

            var entry = new ReportEntry(input, spec.Tool, rev is null ? "unverified" : "success", before, after, note, DateTime.Now, outFile);
            ReportHub.Add(entry);
            return entry;
        }
        catch (OperationCanceledException)
        {
            // cancelled between "convert" and "verify": the output was never verified, so it must not stay behind
            if (rev is not null && outFile is not null) { try { File.Delete(outFile); } catch { } }
            throw;
        }
        catch (Exception ex)
        {
            // A result that had to be verified (round-trip) but was not is removed - never left next to good files.
            if (outFile is not null && (ex is RoundTripException || rev is not null)) { try { File.Delete(outFile); } catch { } }
            OpLog.Write(spec.Tool, "FAILED", name, ex.Message);
            ReportHub.Add(new ReportEntry(input, spec.Tool, "failed", before, after, ex.Message, DateTime.Now));
            throw;
        }
    }

    static string Short(string s) => s.Length <= 300 ? s.Replace('\n', ' ') : s[..300].Replace('\n', ' ') + "…";

    static readonly object UniqueGate = new();
    static readonly HashSet<string> Reserved = new(StringComparer.OrdinalIgnoreCase);

    /// <summary>Thread-safe: the chosen name is reserved under a lock, so parallel callers can never get the same one.</summary>
    static string Unique(string p)
    {
        lock (UniqueGate)
        {
            string d = Path.GetDirectoryName(p)!, n = Path.GetFileNameWithoutExtension(p), x = Path.GetExtension(p), c = p;
            for (int i = 2; File.Exists(c) || Reserved.Contains(c); i++) c = Path.Combine(d, $"{n}_{i}{x}");
            Reserved.Add(c);
            return c;
        }
    }
}

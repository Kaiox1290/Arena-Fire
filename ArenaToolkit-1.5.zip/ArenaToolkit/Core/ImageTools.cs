using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;

namespace Arena.Core;

public static class ImageTools
{
    /// <summary>Open an image; turn GDI+'s cryptic errors into a clear one.</summary>
    static Bitmap Open(string path)
    {
        try { return new Bitmap(path); }
        catch (Exception ex) when (ex is ArgumentException or OutOfMemoryException)
        {
            throw new InvalidDataException("This file is not a readable image (corrupted or unsupported format).", ex);
        }
    }

    public static (int w, int h) GetSize(string path)
    {
        using var b = Open(path);
        return (b.Width, b.Height);
    }

    static Bitmap ToBitmap(int w, int h, byte[] bgra)
    {
        var bmp = new Bitmap(w, h, PixelFormat.Format32bppArgb);
        var bd = bmp.LockBits(new Rectangle(0, 0, w, h), ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
        try { for (int y = 0; y < h; y++) Marshal.Copy(bgra, y * w * 4, bd.Scan0 + y * bd.Stride, w * 4); }
        finally { bmp.UnlockBits(bd); }
        return bmp;
    }

    public static void SavePng(int w, int h, byte[] bgra, string path)
    {
        using var bmp = ToBitmap(w, h, bgra);
        Atomic.Write(path, tmp => bmp.Save(tmp, ImageFormat.Png));
    }

    /// <summary>Saves BGRA pixels as png / jpg / bmp, chosen by the file extension (png when unknown). Atomic.</summary>
    public static void Save(int w, int h, byte[] bgra, string path)
    {
        using var bmp = ToBitmap(w, h, bgra);
        switch (Path.GetExtension(path).ToLowerInvariant())
        {
            case ".jpg":
            case ".jpeg":
                var enc = ImageCodecInfo.GetImageEncoders().First(e => e.FormatID == ImageFormat.Jpeg.Guid);
                Atomic.Write(path, tmp =>
                {
                    using var ep = new EncoderParameters(1);
                    ep.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, 95L);
                    bmp.Save(tmp, enc, ep);
                });
                break;
            case ".bmp": Atomic.Write(path, tmp => bmp.Save(tmp, ImageFormat.Bmp)); break;
            default: Atomic.Write(path, tmp => bmp.Save(tmp, ImageFormat.Png)); break;
        }
    }

    /// <summary>Exact pixel conversion to 32-bit BGRA (no resampling, no DPI scaling, alpha untouched).</summary>
    public static (int w, int h, byte[] bgra) LoadBgra(string path)
    {
        using var src = Open(path);
        int w = src.Width, h = src.Height;
        var px = new byte[w * h * 4];
        var bd = src.LockBits(new Rectangle(0, 0, w, h), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
        try { for (int y = 0; y < h; y++) Marshal.Copy(bd.Scan0 + y * bd.Stride, px, y * w * 4, w * 4); }
        finally { src.UnlockBits(bd); }
        return (w, h, px);
    }

    /// <summary>Like LoadBgra, but also reads .dtx textures.</summary>
    public static (int w, int h, byte[] bgra) LoadAny(string path) =>
        Path.GetExtension(path).Equals(".dtx", StringComparison.OrdinalIgnoreCase)
            ? DtxCodec.Decode(File.ReadAllBytes(path))
            : LoadBgra(path);

    public static (int w, int h) Compute(int sw, int sh, int? tw, int? th, bool keep, double? pct)
    {
        if (pct is > 0 && tw is null && th is null)
            return (Math.Max(1, (int)Math.Round(sw * pct.Value / 100)), Math.Max(1, (int)Math.Round(sh * pct.Value / 100)));
        if (tw is null && th is null) throw new ArgumentException("Enter a width, a height, or a percent.");
        if (!keep) return (tw ?? sw, th ?? sh);

        double scale = tw is not null && th is not null ? Math.Min((double)tw / sw, (double)th / sh)
                     : tw is not null ? (double)tw / sw : (double)th! / sh;
        return (Math.Max(1, (int)Math.Round(sw * scale)), Math.Max(1, (int)Math.Round(sh * scale)));
    }

    // ───────────────────────── resampling ─────────────────────────
    sealed class Axis
    {
        public int[] Start = Array.Empty<int>(), Count = Array.Empty<int>(), Off = Array.Empty<int>();
        public float[] W = Array.Empty<float>();
    }

    static double Lanczos3(double x)
    {
        x = Math.Abs(x);
        if (x >= 3.0) return 0.0;
        if (x < 1e-8) return 1.0;
        double p = Math.PI * x;
        return 3.0 * Math.Sin(p) * Math.Sin(p / 3.0) / (p * p);
    }

    /// <summary>Per output pixel: first source index, tap count and normalised Lanczos-3 weights (filter widens when shrinking).</summary>
    static Axis Weights(int sn, int dn)
    {
        double scale = (double)dn / sn, fscale = Math.Min(1.0, scale), support = 3.0 / fscale;
        var a = new Axis { Start = new int[dn], Count = new int[dn], Off = new int[dn] };
        var list = new List<float>();
        for (int i = 0; i < dn; i++)
        {
            double center = (i + 0.5) / scale;
            int left = Math.Max(0, (int)Math.Floor(center - support)), right = Math.Min(sn - 1, (int)Math.Ceiling(center + support));
            if (right < left) left = right = Math.Min(sn - 1, Math.Max(0, (int)center));
            a.Start[i] = left; a.Off[i] = list.Count; a.Count[i] = right - left + 1;
            double sum = 0;
            var ws = new double[right - left + 1];
            for (int j = left; j <= right; j++) { ws[j - left] = Lanczos3((j + 0.5 - center) * fscale); sum += ws[j - left]; }
            for (int k = 0; k < ws.Length; k++) list.Add((float)(Math.Abs(sum) > 1e-9 ? ws[k] / sum : (k == 0 ? 1.0 : 0.0)));
        }
        a.W = list.ToArray();
        return a;
    }

    /// <summary>
    /// High quality Lanczos-3 resize of straight-alpha BGRA. Works on alpha-weighted (premultiplied) colour, so transparent
    /// areas never leak dark or light halos into the edges of the picture.
    /// </summary>
    public static byte[] ResizePixels(byte[] src, int sw, int sh, int dw, int dh, CancellationToken ct = default)
    {
        if (dw <= 0 || dh <= 0) throw new ArgumentException("Invalid target size.");
        if ((long)dw * dh > 100_000_000L || (long)sh * dw * 4 > 300_000_000L)
            throw new ArgumentException("The target size is too large to resize safely. Try a smaller size.");
        if (sw == dw && sh == dh) return (byte[])src.Clone();

        var wx = Weights(sw, dw);
        var wy = Weights(sh, dh);
        var po = new ParallelOptions { CancellationToken = ct };

        // pass 1: horizontal, every source row -> dw pixels (premultiplied colour B,G,R in 0..255 scale + alpha)
        var tmp = new float[sh * dw * 4];
        Parallel.For(0, sh, po, y =>
        {
            int rowS = y * sw * 4, rowD = y * dw * 4;
            for (int x = 0; x < dw; x++)
            {
                float b = 0, g = 0, r = 0, a = 0;
                int s = wx.Start[x], c = wx.Count[x], o = wx.Off[x];
                for (int k = 0; k < c; k++)
                {
                    int p = rowS + (s + k) * 4;
                    float w = wx.W[o + k], al = src[p + 3] * (1f / 255f);
                    b += w * src[p] * al; g += w * src[p + 1] * al; r += w * src[p + 2] * al; a += w * src[p + 3];
                }
                int q = rowD + x * 4;
                tmp[q] = b; tmp[q + 1] = g; tmp[q + 2] = r; tmp[q + 3] = a;
            }
        });

        // pass 2: vertical, then back to straight alpha
        var dst = new byte[dw * dh * 4];
        Parallel.For(0, dh, po, y =>
        {
            int s = wy.Start[y], c = wy.Count[y], o = wy.Off[y];
            for (int x = 0; x < dw; x++)
            {
                float b = 0, g = 0, r = 0, a = 0;
                for (int k = 0; k < c; k++)
                {
                    int q = ((s + k) * dw + x) * 4;
                    float w = wy.W[o + k];
                    b += w * tmp[q]; g += w * tmp[q + 1]; r += w * tmp[q + 2]; a += w * tmp[q + 3];
                }
                int d = (y * dw + x) * 4;
                float al = Math.Min(255f, Math.Max(0f, a));
                if (al > 0.5f)
                {
                    float inv = 255f / al;
                    dst[d] = (byte)Math.Min(255, Math.Max(0, (int)MathF.Round(b * inv)));
                    dst[d + 1] = (byte)Math.Min(255, Math.Max(0, (int)MathF.Round(g * inv)));
                    dst[d + 2] = (byte)Math.Min(255, Math.Max(0, (int)MathF.Round(r * inv)));
                }
                dst[d + 3] = (byte)(int)MathF.Round(al);
            }
        });
        return dst;
    }
}

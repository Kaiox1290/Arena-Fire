#if CFREZ
using System.Security.Cryptography;
using System.Text;
using CFR = CFRezManager;

namespace Arena.Core;

/// <summary>
/// Adapter around the *unmodified* CF Rez Manager classes (ThirdParty/CFRezManager, fetched by setup.bat, never copied into
/// this project). Only compiled when that folder exists (symbol CFREZ). Reads and writes the REZ layout the real client uses.
/// </summary>
public static class RezBackend
{
    public const string Name = "CF Rez Manager (ThirdParty)";

    // ─────────── unpack ───────────
    public static void Unpack(string rezPath, string outDir, Job job, CancellationToken ct)
    {
        var arc = new CFR.RezArchiveReader().Read(rezPath);
        var files = new List<CFR.RezFileNode>();
        void Walk(CFR.RezDirectoryNode d) { foreach (var c in d.Children) { if (c is CFR.RezDirectoryNode sd) Walk(sd); else if (c is CFR.RezFileNode f) files.Add(f); } }
        Walk(arc.Root);
        job.Add(files.Count);

        string root = Path.TrimEndingDirectorySeparator(Path.GetFullPath(outDir));
        Directory.CreateDirectory(root);
        var used = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        int bad = 0; string? first = null;
        foreach (var f in files)
        {
            ct.ThrowIfCancellationRequested();
            try
            {
                string dest = SafePath(root, f.FullPath);
                for (int i = 2; !used.Add(dest); i++)        // two entries with one path never overwrite each other
                    dest = Path.Combine(Path.GetDirectoryName(dest)!, $"{Path.GetFileNameWithoutExtension(dest)}_{i}{Path.GetExtension(dest)}");
                Atomic.Write(dest, tmp => CFR.RezArchiveReader.ExtractFile(arc, f, tmp));
            }
            catch (Exception ex) when (ex is not OperationCanceledException) { bad++; first ??= $"{f.FullPath}: {ex.Message}"; }
            job.Tick();
        }
        if (bad > 0) throw new InvalidDataException($"{bad} of {files.Count} entries failed. First: {first}");
    }

    // ─────────── pack (+ verification by re-reading) ───────────
    public static void Pack(string folder, string outFile, Job job, CancellationToken ct)
    {
        folder = Path.GetFullPath(folder);
        int total = Directory.GetFiles(folder, "*", SearchOption.AllDirectories).Length;
        if (total == 0) throw new InvalidDataException("The folder is empty (nothing to pack).");
        job.Add(total + 1);

        string outFull = Path.GetFullPath(outFile);
        var progress = new SyncProgress<CFR.RezArchiveWriteProgress>(_ => { ct.ThrowIfCancellationRequested(); job.Tick(); });
        try { CFR.RezArchiveWriter.WriteFromDirectory(folder, outFull, progress); }
        catch (InvalidOperationException ex) { throw new InvalidDataException(ex.Message, ex); }   // names / extension rules of the writer
        ct.ThrowIfCancellationRequested();

        try { Verify(folder, outFull); }
        catch { try { File.Delete(outFull); } catch { } throw; }                                   // a pack that fails the check is not kept
        job.Tick();
    }

    /// <summary>Stage (junk / helper PNGs removed, edited PNGs re-encoded to DTX) -> pack with the third-party writer -> verify -> clean up.</summary>
    public static void PackStaged(string folder, string outFile, Job job, CancellationToken ct, Action<string>? warn = null)
    {
        string stage = RezArchive.Stage(folder, job, ct, warn);
        try { Pack(stage, outFile, job, ct); }
        finally { try { Directory.Delete(stage, true); } catch { } }
    }

    /// <summary>Re-reads the written archive with the same reader and compares every entry (path, size, SHA-256) with the folder.</summary>
    public static void Verify(string folder, string rezPath)
    {
        var arc = new CFR.RezArchiveReader().Read(rezPath);
        var src = Directory.GetFiles(folder, "*", SearchOption.AllDirectories)
            .Where(f => !string.Equals(Path.GetFullPath(f), Path.GetFullPath(rezPath), StringComparison.OrdinalIgnoreCase))
            .ToDictionary(f => Path.GetRelativePath(folder, f).Replace('\\', '/'), f => f, StringComparer.OrdinalIgnoreCase);

        var entries = new List<CFR.RezFileNode>();
        void Walk(CFR.RezDirectoryNode d) { foreach (var c in d.Children) { if (c is CFR.RezDirectoryNode sd) Walk(sd); else if (c is CFR.RezFileNode f) entries.Add(f); } }
        Walk(arc.Root);
        if (entries.Count != src.Count)
            throw new InvalidDataException($"Pack verification failed: the archive lists {entries.Count} files but the folder has {src.Count}.");

        using var fs = new FileStream(rezPath, FileMode.Open, FileAccess.Read, FileShare.Read, 1 << 16);
        var buf = new byte[1 << 16];
        foreach (var e in entries)
        {
            string key = e.FullPath.Replace('\\', '/').TrimStart('/');
            if (!src.TryGetValue(key, out var f))
                throw new InvalidDataException($"Pack verification failed: '{key}' is in the archive but not in the folder.");
            if (new FileInfo(f).Length != e.Size)
                throw new InvalidDataException($"Pack verification failed: size of '{key}' differs ({e.Size} vs {new FileInfo(f).Length}).");
            using var h = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
            fs.Position = e.DataOffset;
            for (long left = e.Size; left > 0;)
            {
                int n = fs.Read(buf, 0, (int)Math.Min(buf.Length, left));
                if (n <= 0) throw new EndOfStreamException();
                h.AppendData(buf, 0, n); left -= n;
            }
            using var sf = new FileStream(f, FileMode.Open, FileAccess.Read, FileShare.Read, 1 << 16);
            if (!h.GetHashAndReset().AsSpan().SequenceEqual(SHA256.HashData(sf)))
                throw new InvalidDataException($"Pack verification failed: content of '{key}' differs from the source file.");
        }
    }

    static string SafePath(string root, string rel)
    {
        var parts = rel.Split('/', '\\').Select(Clean).Where(s => s.Length > 0).ToArray();
        string p = Path.GetFullPath(Path.Combine(new[] { root }.Concat(parts).ToArray()));
        if (!p.StartsWith(root + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("Blocked unsafe path: " + rel);
        return p;
    }
    static string Clean(string s)
    {
        if (s is "." or "..") return "_";
        foreach (var c in Path.GetInvalidFileNameChars()) s = s.Replace(c, '_');
        return s.Trim();
    }

    sealed class SyncProgress<T> : IProgress<T> { readonly Action<T> a; public SyncProgress(Action<T> a) => this.a = a; public void Report(T v) => a(v); }
}
#endif

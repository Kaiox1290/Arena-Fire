namespace Arena.Core;

/// <summary>Thread-safe progress counter shared by all workers of one batch.</summary>
public sealed class Job
{
    long _total, _done;
    public long Total => Interlocked.Read(ref _total);
    public long Done => Interlocked.Read(ref _done);
    public volatile string Current = "";
    public void Add(long n) => Interlocked.Add(ref _total, n);
    public void Tick() => Interlocked.Increment(ref _done);
}

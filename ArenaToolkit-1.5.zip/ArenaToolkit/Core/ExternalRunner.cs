using System.Diagnostics;

namespace Arena.Core;

public static class ExternalRunner
{
    /// <summary>Runs the configured external converter. Returns its console output; throws on any problem.</summary>
    public static string Run(string key, ExternalToolCfg t, string input, string output, CancellationToken ct)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(output))!);
        var psi = new ProcessStartInfo
        {
            FileName = t.Path, UseShellExecute = false, CreateNoWindow = true,
            RedirectStandardOutput = true, RedirectStandardError = true,
            WorkingDirectory = Path.GetDirectoryName(Path.GetFullPath(t.Path)) ?? Environment.CurrentDirectory
        };
        foreach (var a in t.Args)
            psi.ArgumentList.Add(a.Replace("{app}", AppContext.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar))
                                  .Replace("{in}", input).Replace("{out}", output)
                                  .Replace("{outdir}", Path.GetDirectoryName(Path.GetFullPath(output))!)
                                  .Replace("{name}", Path.GetFileNameWithoutExtension(input)));

        using var p = Process.Start(psi) ?? throw new ExternalToolException(key, -1, "process could not be started");
        var so = p.StandardOutput.ReadToEndAsync();
        var se = p.StandardError.ReadToEndAsync();
        var sw = Stopwatch.StartNew();
        while (!p.WaitForExit(200))
        {
            if (ct.IsCancellationRequested) { Kill(p); ct.ThrowIfCancellationRequested(); }
            if (sw.Elapsed.TotalSeconds > Math.Max(5, t.TimeoutSec)) { Kill(p); throw new ExternalToolException(key, -1, $"timed out after {t.TimeoutSec}s"); }
        }
        p.WaitForExit();
        string text = (so.Result + Environment.NewLine + se.Result).Trim();

        if (p.ExitCode != 0) throw new ExternalToolException(key, p.ExitCode, text.Length == 0 ? "no output" : text);
        if (!File.Exists(output) || new FileInfo(output).Length == 0)
            throw new ExternalToolException(key, 0, $"the tool finished but did not create the expected output file: {output}. Check Args (use {{out}} or {{outdir}}).");
        return text;
    }

    static void Kill(Process p) { try { p.Kill(true); } catch { } }
}

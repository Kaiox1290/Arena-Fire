namespace Arena.Core;

/// <summary>External tool missing / not configured / bad args in config.json.</summary>
public sealed class ToolConfigException : Exception
{
    public ToolConfigException(string message) : base(message) { }
}

/// <summary>The external converter failed (exit code, timeout, or no output).</summary>
public sealed class ExternalToolException : Exception
{
    public string Tool { get; }
    public int ExitCode { get; }
    public ExternalToolException(string tool, int exitCode, string message)
        : base($"External tool '{tool}' failed (exit code {exitCode}): {message}") { Tool = tool; ExitCode = exitCode; }
}

/// <summary>original → convert → back did not give the same bytes.</summary>
public sealed class RoundTripException : Exception
{
    public long Offset { get; }
    public RoundTripException(string message, long offset) : base(message) { Offset = offset; }
}

using System.Text;

namespace Arena.Core;

public sealed record TextInfo(Encoding Enc, string Label, int BomLen);

public static class TextDetect
{
    /// <summary>
    /// BOM → UTF-8 strict → otherwise 8-bit Latin-1 (1:1 byte mapping, lossless round-trip; the real legacy codepage is NOT guessed).
    /// </summary>
    public static TextInfo Detect(byte[] b)
    {
        if (b.Length >= 3 && b[0] == 0xEF && b[1] == 0xBB && b[2] == 0xBF) return new(new UTF8Encoding(true), "UTF-8 (BOM)", 3);
        if (b.Length >= 2 && b[0] == 0xFF && b[1] == 0xFE) return new(Encoding.Unicode, "UTF-16 LE (BOM)", 2);
        if (b.Length >= 2 && b[0] == 0xFE && b[1] == 0xFF) return new(Encoding.BigEndianUnicode, "UTF-16 BE (BOM)", 2);
        if (b.All(x => x < 0x80)) return new(new UTF8Encoding(false), "ASCII", 0);
        try { new UTF8Encoding(false, true).GetString(b); return new(new UTF8Encoding(false), "UTF-8", 0); }
        catch (DecoderFallbackException) { return new(Encoding.Latin1, "8-bit legacy (codepage unconfirmed, bytes preserved)", 0); }
    }
}

public sealed record CsvInfo(string Encoding, string Newline, int Rows, int BlankLines, char? Delimiter, int Columns, int RaggedRows)
{
    public string Summary =>
        $"encoding={Encoding}; newline={Newline}; rows={Rows}; blank lines={BlankLines}; " +
        $"delimiter={(Delimiter is null ? "not detected" : Delimiter == '\t' ? "TAB" : Delimiter.ToString())}; " +
        $"columns={Columns} (read from file); rows with a different column count={RaggedRows}";
}

/// <summary>Reads the layout from the file itself. Nothing is fixed or rewritten.</summary>
public static class CsvAnalyzer
{
    static readonly char[] Candidates = { ',', ';', '\t', '|' };

    public static CsvInfo Analyze(string path)
    {
        var bytes = File.ReadAllBytes(path);
        var ti = TextDetect.Detect(bytes);
        string text = ti.Enc.GetString(bytes, ti.BomLen, bytes.Length - ti.BomLen);

        string nl = text.Contains("\r\n") ? "CRLF" : text.Contains('\n') ? "LF" : "none";
        var lines = text.Split('\n').Select(l => l.TrimEnd('\r')).ToList();
        if (lines.Count > 0 && lines[^1].Length == 0) lines.RemoveAt(lines.Count - 1);   // final newline
        int blank = lines.Count(l => l.Length == 0);
        var data = lines.Where(l => l.Length > 0).ToList();

        char? delim = null;
        if (data.Count > 0)
        {
            var sample = data.Take(50).ToList();
            int best = 0;
            foreach (var c in Candidates)
            {
                int first = Count(sample[0], c);
                if (first == 0) continue;
                int same = sample.Count(l => Count(l, c) == first);
                if (same >= sample.Count * 0.8 && first > best) { best = first; delim = c; }
            }
        }
        int cols = data.Count == 0 ? 0 : delim is null ? 1 : Count(data[0], delim.Value) + 1;
        int ragged = delim is null ? 0 : data.Count(l => Count(l, delim.Value) + 1 != cols);
        return new CsvInfo(ti.Label, nl, data.Count, blank, delim, cols, ragged);
    }

    static int Count(string line, char d)
    {
        int n = 0; bool q = false;
        foreach (char ch in line) { if (ch == '"') q = !q; else if (ch == d && !q) n++; }
        return n;
    }
}

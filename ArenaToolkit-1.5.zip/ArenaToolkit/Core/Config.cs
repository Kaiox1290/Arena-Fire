using System.Text.Json;

namespace Arena.Core;

public sealed class ExternalToolCfg
{
    public string Path { get; set; } = "";
    public List<string> Args { get; set; } = new();
    public int TimeoutSec { get; set; } = 120;
}

/// <summary>
/// config.json (next to the exe). Nothing is guessed: a converter whose tool is not configured stops with a clear message.
/// Args placeholders: {in} {out} {outdir} {name}
/// </summary>
public sealed class ArenaConfig
{
    public string Help { get; set; } =
        "Set Path to the external tool (.exe) and Args as a list. Placeholders: {in} {out} {outdir} {name} {app}. " +
        "Check each tool's real command line yourself - nothing is guessed here. Leave Path empty = converter disabled.";
    public string WorkDir { get; set; } = "";
    public bool RequireRoundTrip { get; set; } = true;
    public Dictionary<string, ExternalToolCfg> Tools { get; set; } = new();

    public static readonly string[] ToolKeys =
    {
        "cft_to_csv", "csv_to_cft", "ltc_to_lta", "lta_to_ltc", "enc_to_txt", "txt_to_enc",
        "dat_to_lta", "fxf_convert", "ltb_to_glb", "dtx_to_png", "png_to_dtx"
    };

    static readonly JsonSerializerOptions Opt = new()
    {
        WriteIndented = true, ReadCommentHandling = JsonCommentHandling.Skip,
        AllowTrailingCommas = true, PropertyNameCaseInsensitive = true
    };

    public static string FilePath =>
        System.IO.Path.Combine(System.IO.Path.GetDirectoryName(Environment.ProcessPath) ?? AppContext.BaseDirectory, "config.json");

    public static ArenaConfig Load()
    {
        string f = FilePath;
        ArenaConfig c;
        if (File.Exists(f))
        {
            try { c = JsonSerializer.Deserialize<ArenaConfig>(File.ReadAllText(f), Opt) ?? new(); }
            catch (JsonException ex) { throw new InvalidDataException($"config.json is invalid: {ex.Message}  (file: {f})"); }
        }
        else c = new();

        foreach (var k in ToolKeys) if (!c.Tools.ContainsKey(k)) c.Tools[k] = new ExternalToolCfg();
        if (!File.Exists(f)) { try { File.WriteAllText(f, JsonSerializer.Serialize(c, Opt)); } catch { /* read-only folder: fine */ } }
        return c;
    }

    public string ResolveWorkDir() => string.IsNullOrWhiteSpace(WorkDir)
        ? System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Team Arena Output")
        : WorkDir;

    public bool IsConfigured(string key) => Tools.TryGetValue(key, out var t) && !string.IsNullOrWhiteSpace(t.Path);

    /// <summary>Absolute path of a configured tool: as given, next to the exe, next to config.json's folder, current folder, then PATH. Null = not found.</summary>
    public static string? ResolveTool(string p)
    {
        p = Environment.ExpandEnvironmentVariables(p.Trim().Trim('"'));
        if (p.Length == 0) return null;
        if (System.IO.Path.IsPathRooted(p)) return File.Exists(p) ? p : null;
        var bases = new List<string> { AppContext.BaseDirectory, Environment.CurrentDirectory };
        bases.AddRange((Environment.GetEnvironmentVariable("PATH") ?? "").Split(System.IO.Path.PathSeparator, StringSplitOptions.RemoveEmptyEntries));
        foreach (var b in bases)
        {
            try { var full = System.IO.Path.GetFullPath(System.IO.Path.Combine(b, p)); if (File.Exists(full)) return full; } catch { }
        }
        return null;
    }

    public ExternalToolCfg Require(string key, string? requiredArg = null)
    {
        if (!IsConfigured(key))
            throw new ToolConfigException($"External tool '{key}' is not configured. Open config.json ({FilePath}) and set Tools.{key}.Path and Tools.{key}.Args.");
        var t = Tools[key];
        string? full = ResolveTool(t.Path);
        if (full is null)
            throw new ToolConfigException($"Tools.{key}.Path points to a file that does not exist: {t.Path}");
        if (requiredArg is not null && !t.Args.Contains(requiredArg))
            throw new ToolConfigException($"Tools.{key}.Args must include '{requiredArg}' (required by this converter).");
        return new ExternalToolCfg { Path = full, Args = t.Args, TimeoutSec = t.TimeoutSec };   // copy: the loaded config is never modified
    }
}

namespace Arena.Core;

/// <summary>Write-then-swap helpers: a crash, a cancel or a full disk can never leave a half-written output file.</summary>
public static class Atomic
{
    public static void WriteBytes(string path, byte[] data) => Write(path, tmp => File.WriteAllBytes(tmp, data));

    public static void Write(string path, Action<string> writer)
    {
        string tmp = path + ".arn_tmp";
        try
        {
            writer(tmp);
            File.Move(tmp, path, true);
        }
        catch
        {
            try { File.Delete(tmp); } catch { }
            throw;
        }
    }
}

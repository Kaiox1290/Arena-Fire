using System.Collections.Concurrent;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO.Compression;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Microsoft.Win32;
using Arena.Core;

namespace Arena;

// ───────────────────────── models ─────────────────────────
public sealed class FileItem : INotifyPropertyChanged
{
    public string FullPath { get; }
    public string Name { get; }
    public string Ext { get; }
    public string Badge { get; }
    public string SizeText { get; }
    public Brush BadgeBrush { get; }

    string status = "";
    Brush statusBrush = Brushes.Transparent;
    public string Status { get => status; private set { status = value; Raise(nameof(Status)); } }
    public Brush StatusBrush { get => statusBrush; private set { statusBrush = value; Raise(nameof(StatusBrush)); } }
    public event PropertyChangedEventHandler? PropertyChanged;
    void Raise(string n) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n));

    readonly ConcurrentQueue<string> warns = new();
    public void Warn(string message) => warns.Enqueue(message);
    public IReadOnlyCollection<string> Warnings => warns;
    public void ClearWarnings() => warns.Clear();

    public void SetState(string text, Color c)
    {
        var b = new SolidColorBrush(c); b.Freeze();
        Status = text; StatusBrush = b;
    }

    public FileItem(string path)
    {
        FullPath = path;
        bool dir = Directory.Exists(path);
        Name = Path.GetFileName(path.TrimEnd('\\', '/'));
        if (Name.Length == 0) Name = path;
        Ext = dir ? "dir" : Path.GetExtension(path).TrimStart('.').ToLowerInvariant();
        long size = dir || !File.Exists(path) ? 0 : new FileInfo(path).Length;
        SizeText = dir ? "folder" : Human(size);
        Badge = Ext.Length == 0 ? "?" : (Ext.Length > 4 ? Ext[..4] : Ext).ToUpperInvariant();
        var c = Ext switch
        {
            "rez" or "dir" => Color.FromRgb(0xFF, 0x8A, 0x1F),
            "dtx" => Color.FromRgb(0xFF, 0xC1, 0x45),
            "png" or "jpg" or "jpeg" or "bmp" or "gif" or "ico" => Color.FromRgb(0x7B, 0xE0, 0xA8),
            "dll" or "exe" or "ocx" => Color.FromRgb(0xFF, 0x5A, 0x4D),
            "ini" or "cfg" or "txt" or "inf" or "xml" or "json" or "lua" => Color.FromRgb(0xF2, 0xB8, 0xA0),
            _ => Color.FromRgb(0xA8, 0xA3, 0x9B)
        };
        var br = new SolidColorBrush(c); br.Freeze();
        BadgeBrush = br;
    }

    public static string Human(long n)
    {
        string[] u = { "B", "KB", "MB", "GB" };
        double v = n; int i = 0;
        while (v >= 1024 && i < u.Length - 1) { v /= 1024; i++; }
        return $"{v:0.#} {u[i]}";
    }
}

sealed record ToolDef(string Key, string Title, string Sub, string Desc, string DropText, string Badge,
                      Color Color, string[] Exts, bool Folders = false);

sealed class ToolState
{
    public required ToolDef Def { get; init; }
    public ObservableCollection<FileItem> Items { get; } = new();
    public HashSet<string> Known { get; } = new(StringComparer.OrdinalIgnoreCase);
    public List<FileItem> Pending { get; } = new();   // dropped while another job was running
    public RadioButton? Btn { get; set; }
    public TextBlock? Sub { get; set; }
}

// ───────────────────────── window ─────────────────────────
public partial class MainWindow : Window
{
    static readonly bool Anim = SystemParameters.ClientAreaAnimation;   // honours "reduce motion"
    static TimeSpan D(int ms) => Anim ? TimeSpan.FromMilliseconds(ms) : TimeSpan.Zero;

    static Color C(byte r, byte g, byte b) => Color.FromRgb(r, g, b);
    static readonly Color Amber = C(0xFF, 0xB3, 0x47), Green = C(0x7B, 0xE0, 0xA8), Red = C(0xFF, 0x5A, 0x4D), Gray = C(0x8E, 0x8A, 0x84);

    static readonly string[] ImgExt = { "png", "jpg", "jpeg", "bmp", "gif", "ico" };
    static readonly string[] TextExt = { "ini", "cfg", "txt", "inf", "xml", "json", "lua" };

    static readonly ToolDef[] Defs =
    {
        new("rez", "REZ Unpack", "Unpack archives",
            "Drop one or many .rez files (or folders full of them). Everything inside is extracted in parallel.",
            "Drop .rez files here", "REZ", C(0xFF, 0x8A, 0x1F), new[] { "rez" }),
        new("pack", "REZ Pack", "Folder → .rez",
            "Drop a folder and it is packed into a single .rez archive.",
            "Drop a folder here", "PACK", C(0xFF, 0x8A, 0x1F), Array.Empty<string>(), true),
        new("dtx", "DTX → PNG", "Textures to images",
            "Drop .dtx textures (DXT1 / DXT3 / DXT5 / 32-bit) and get PNG files.",
            "Drop .dtx files here", "DTX", C(0xFF, 0xC1, 0x45), new[] { "dtx" }),
        new("png2dtx", "PNG → DTX", "Images to textures",
            "Drop PNG / JPG / BMP images and get .dtx textures.",
            "Drop images here", "DTX", C(0xFF, 0xC1, 0x45), new[] { "png", "jpg", "jpeg", "bmp" }),
        new("resize", "Resize", "Smart Lanczos",
            "Set a size or a percent, then drop images or .dtx textures. High-quality Lanczos, keeps the ratio.",
            "Drop images here", "IMG", C(0x7B, 0xE0, 0xA8), new[] { "png", "jpg", "jpeg", "bmp", "gif", "dtx" }),
        new("icons", "Icons", "From dll / exe / ico",
            "Drop .dll / .exe / .ico files — every icon is extracted as PNG (up to 256 px) plus a multi-size .ico.",
            "Drop dll / exe / ico here", "DLL", C(0xFF, 0x5A, 0x4D), new[] { "dll", "exe", "ico", "ocx" }),
        new("config", "Config & DAT", "ini · cfg · dat · dll",
            "Drop config or data files, then select one: edit ini / cfg / txt (a .bak is kept), or inspect dat / dll in hex.",
            "Drop ini / cfg / dat / dll here", "CFG", C(0xF2, 0xB8, 0xA0),
            new[] { "ini", "cfg", "dat", "txt", "inf", "xml", "json", "lua", "dll", "exe", "ocx" }),

        // ── CrossFire 2.0 (Lithtech Jupiter) converters: external tools from config.json, SHA-256 round-trip ──
        new("cft", "CFT ↔ CSV", "item.cft · MAP.CFT",
            "Drop .cft to get .csv, or .csv to get .cft. Columns are read from the file itself. Needs the decrypt/encrypt tools in config.json.",
            "Drop .cft or .csv files here", "CFT", C(0xFF, 0x8A, 0x1F), new[] { "cft", "csv" }),
        new("ltc", "LTC ↔ LTA", "CFLTC_Converter",
            "Drop .ltc to get .lta, or .lta to get .ltc. Runs the converter set in config.json.",
            "Drop .ltc or .lta files here", "LTC", C(0xFF, 0x8A, 0x1F), new[] { "ltc", "lta" }),
        new("enc", "ENC ↔ TXT", "AI scripts",
            "Drop .enc to get .txt, or .txt to get .enc. Runs the converter set in config.json.",
            "Drop .enc or .txt files here", "ENC", C(0xF2, 0xB8, 0xA0), new[] { "enc", "txt" }),
        new("dat", "DAT → LTA", "dat2lta  (-v1)",
            "Drop map .dat files to get .lta. One-way: LTA → DAT is done in DEdit, not here. The -v1 flag is required.",
            "Drop .dat files here", "DAT", C(0xFF, 0xC1, 0x45), new[] { "dat" }),
        new("fx", "FXF / FCF 3.0 → 2.0", "clientfx_tool",
            "Drop .fxf / .fcf files to convert them from 3.0 to 2.0 with the tool set in config.json. One-way.",
            "Drop .fxf / .fcf files here", "FX", C(0xFF, 0xC1, 0x45), new[] { "fxf", "fcf" }),
        new("ltbglb", "LTB → GLB", "cf_ltb_exporter.py",
            "Drop .ltb models to get .glb (bones + animation). One-way export through the Python exporter set in config.json (Tools.ltb_to_glb).",
            "Drop .ltb files here", "GLB", C(0xFF, 0xC1, 0x45), new[] { "ltb" }),
        new("ltb", "LTB info", "read only",
            "Drop .ltb files: only size, SHA-256 and a header hex dump are written. Full conversion is unconfirmed and not attempted.",
            "Drop .ltb files here", "LTB", C(0xA8, 0xA3, 0x9B), new[] { "ltb" }),
        new("unsup", "Unsupported", "MSZ CTL TAD ATL NAV",
            "These formats are unconfirmed and need reverse engineering. Dropped files are NOT touched, only listed as unsupported in the JSON report.",
            "Drop msz / ctl / tad / atl / nav here", "N/A", C(0xA8, 0xA3, 0x9B), new[] { "msz", "ctl", "tad", "atl", "nav" }),
    };

    static readonly HashSet<string> ConvKeys = new() { "cft", "ltc", "enc", "dat", "fx", "ltbglb" };

    /// <summary>Which converter + direction for this file. Direction comes from the extension; nothing is guessed.</summary>
    static ConvSpec SpecFor(string key, string ext) => (key, ext) switch
    {
        ("cft", "cft") => new("CFT → CSV", "CFT", "cft_to_csv", "csv_to_cft", ".csv"),
        ("cft", "csv") => new("CSV → CFT", "CFT", "csv_to_cft", "cft_to_csv", ".cft"),
        ("ltc", "ltc") => new("LTC → LTA", "LTC", "ltc_to_lta", "lta_to_ltc", ".lta"),
        ("ltc", "lta") => new("LTA → LTC", "LTC", "lta_to_ltc", "ltc_to_lta", ".ltc"),
        ("enc", "enc") => new("ENC → TXT", "ENC", "enc_to_txt", "txt_to_enc", ".txt"),
        ("enc", "txt") => new("TXT → ENC", "ENC", "txt_to_enc", "enc_to_txt", ".enc"),
        ("dat", _) => new("DAT → LTA", "DAT", "dat_to_lta", null, ".lta", OneWay: true, RequiredArg: "-v1"),
        ("fx", _) => new("FXF/FCF 3.0 → 2.0", "FX", "fxf_convert", null, "", OneWay: true),
        ("ltbglb", _) => new("LTB → GLB", "LTBGLB", "ltb_to_glb", null, ".glb", OneWay: true),
        _ => throw new NotSupportedException($"No converter for .{ext}")
    };

    readonly object extGate = new();   // external tools run one at a time (safe for tools that share temp files)
    ArenaConfig cfg = new();

    readonly Dictionary<string, ToolState> tools = new();
    string outRoot = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Team Arena Output");

    ToolState cur = null!;
    CancellationTokenSource? cts, toastCts;
    ArenaError? toastErr;
    bool busy, loaded, closing, dirty, suppressEdit;
    bool? narrow;
    int ticket;
    string? editPath;
    string editLabel = "", editNl = "\r\n";
    bool editAnsi;
    Encoding editEnc = new UTF8Encoding(false);
    readonly Dictionary<string, string> drafts = new(StringComparer.OrdinalIgnoreCase);   // unsaved edits survive selection changes

    static readonly object UniqueGate = new();
    static readonly HashSet<string> Reserved = new(StringComparer.OrdinalIgnoreCase);

    Brush Res(string key) => (Brush)FindResource(key);

    public MainWindow()
    {
        InitializeComponent();
        try
        {
            cfg = ArenaConfig.Load();
            Workspace.Init(cfg.ResolveWorkDir());          // creates backup/ and logs/
            outRoot = Path.Combine(cfg.ResolveWorkDir(), "output");
            Directory.CreateDirectory(outRoot);
        }
        catch (Exception ex)
        {
            ErrorHub.Report(ex, "CONFIG", ArenaConfig.FilePath, true);
            string fallback = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Team Arena Output");
            Workspace.Init(fallback);
            outRoot = Path.Combine(fallback, "output");
            Directory.CreateDirectory(outRoot);
        }
        ErrorHub.Raised += e => Dispatcher.InvokeAsync(() => Toast($"{e.Message}   ·   {e.Code}", true, e));
        BuildNav();
        PreviewKeyDown += (_, e) =>
        {
            if (e.Key == Key.S && Keyboard.Modifiers == ModifierKeys.Control && SaveBtn.Visibility == Visibility.Visible)
            {
                OnSave(this, new RoutedEventArgs());
                e.Handled = true;
            }
        };
    }

    // ───────────────────────── sidebar ─────────────────────────
    void BuildNav()
    {
        foreach (var def in Defs)
        {
            var st = new ToolState { Def = def };
            tools[def.Key] = st;

            var badge = new Border
            {
                Width = 40, Height = 28, CornerRadius = new CornerRadius(8), HorizontalAlignment = HorizontalAlignment.Left,
                VerticalAlignment = VerticalAlignment.Center, Background = new SolidColorBrush(def.Color),
                Child = new TextBlock
                {
                    Text = def.Badge, FontSize = 10, FontWeight = FontWeights.Black, Foreground = Res("OnAccent"),
                    HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center
                }
            };
            var title = new TextBlock { Text = def.Title, FontSize = 13.5, FontWeight = FontWeights.SemiBold, Foreground = Res("Text") };
            var sub = new TextBlock { Text = def.Sub, FontSize = 11, Foreground = Res("Muted") };
            var texts = new StackPanel { Margin = new Thickness(50, 0, 0, 0), VerticalAlignment = VerticalAlignment.Center };
            texts.Children.Add(title); texts.Children.Add(sub);
            var g = new Grid(); g.Children.Add(badge); g.Children.Add(texts);

            var rb = new RadioButton { Style = (Style)FindResource("Nav"), GroupName = "tools", Content = g, Width = 218 };
            rb.Checked += (_, _) => SelectTool(st);
            st.Btn = rb; st.Sub = sub;
            NavPanel.Children.Add(rb);
        }
        tools[Defs[0].Key].Btn!.IsChecked = true;
    }

    string ConvHint(string key)
    {
        try
        {
            var c = ArenaConfig.Load();
            var missing = c.Tools.Where(kv => ArenaConfig.ToolKeys.Contains(kv.Key) && !c.IsConfigured(kv.Key)
                && ConvKeysFor(key).Contains(kv.Key)).Select(kv => kv.Key).ToList();
            return missing.Count == 0
                ? "External tool ready. Each file: backup → convert → convert back → SHA-256 compare."
                : "⚠ Not configured in config.json: " + string.Join(", ", missing) + "   (press ⚙ Config)";
        }
        catch (Exception ex) { return "⚠ " + ex.Message; }
    }

    static string[] ConvKeysFor(string key) => key switch
    {
        "cft" => new[] { "cft_to_csv", "csv_to_cft" },
        "ltc" => new[] { "ltc_to_lta", "lta_to_ltc" },
        "enc" => new[] { "enc_to_txt", "txt_to_enc" },
        "dat" => new[] { "dat_to_lta" },
        "fx" => new[] { "fxf_convert" },
        "ltbglb" => new[] { "ltb_to_glb" },
        _ => Array.Empty<string>()
    };

    void SelectTool(ToolState st)
    {
        cur = st;
        ticket++;
        var d = st.Def;
        FileList.ItemsSource = st.Items;
        ToolTitle.Text = d.Title;
        ToolDesc.Text = d.Desc;
        DropTitle.Text = d.DropText;
        DropHint.Text = d.Folders ? "or click to choose a folder" : "or click to browse  ·  processing starts automatically";

        DeepBox.Visibility = d.Key == "rez" ? Visibility.Visible : Visibility.Collapsed;
        DxtBox.Visibility = d.Key == "png2dtx" ? Visibility.Visible : Visibility.Collapsed;
        OptResize.Visibility = d.Key == "resize" ? Visibility.Visible : Visibility.Collapsed;
        OptHint.Visibility = d.Key is "rez" or "resize" or "png2dtx" ? Visibility.Collapsed : Visibility.Visible;
        OptHint.Text = d.Key == "config" ? "Select a file on the left to view or edit it. A .bak copy is kept next to the file on every save."
            : ConvKeys.Contains(d.Key) ? ConvHint(d.Key)
            : d.Key == "ltb" ? "Read only. Nothing is converted or changed."
            : d.Key == "unsup" ? "Unconfirmed formats: reported as unsupported, files are never modified."
            : "Files are processed automatically the moment you drop them.";
        RerunBtn.Visibility = d.Key is "config" or "unsup" ? Visibility.Collapsed : Visibility.Visible;

        UpdateCount();
        ResetPreview();

        if (loaded)
        {
            var ease = new CubicEase { EasingMode = EasingMode.EaseOut };
            MainPane.BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, D(260)));
            MainShift.BeginAnimation(TranslateTransform.YProperty, new DoubleAnimation(14, 0, D(320)) { EasingFunction = ease });
        }
    }

    // ───────────────────────── window / animation / layout ─────────────────────────
    void OnLoaded(object s, RoutedEventArgs e)
    {
        loaded = true;
        if (!Anim) { RootScale.ScaleX = RootScale.ScaleY = 1; return; }   // reduced motion: no looping / entrance effects

        var ease = new CubicEase { EasingMode = EasingMode.EaseOut };
        BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, D(380)));
        var pop = new DoubleAnimation(0.96, 1, D(460)) { EasingFunction = ease };
        RootScale.BeginAnimation(ScaleTransform.ScaleXProperty, pop);
        RootScale.BeginAnimation(ScaleTransform.ScaleYProperty, pop);

        Drift(BlobA, Canvas.LeftProperty, -120, 90, 9);
        Drift(BlobA, Canvas.TopProperty, -160, -50, 11);
        Drift(BlobB, Canvas.LeftProperty, 780, 560, 10);
        Drift(BlobB, Canvas.TopProperty, 400, 480, 12);
        Drift(DropBob, TranslateTransform.YProperty, 0, 7, 1.1);
    }

    static AnimationTimeline Loop(double a, double b, double secs)
    {
        var anim = new DoubleAnimation(a, b, TimeSpan.FromSeconds(secs))
        {
            AutoReverse = true,
            RepeatBehavior = RepeatBehavior.Forever,
            EasingFunction = new SineEase { EasingMode = EasingMode.EaseInOut }
        };
        Timeline.SetDesiredFrameRate(anim, 30);   // slow ambient motion: 30 fps looks the same and costs half
        return anim;
    }
    static void Drift(UIElement el, DependencyProperty p, double a, double b, double secs) => el.BeginAnimation(p, Loop(a, b, secs));
    static void Drift(Animatable el, DependencyProperty p, double a, double b, double secs) => el.BeginAnimation(p, Loop(a, b, secs));

    void OnSizeChanged(object s, SizeChangedEventArgs e)
    {
        bool n = ActualWidth < 940;
        if (narrow == n) return;
        narrow = n;
        ApplyLayout(n);
    }

    /// <summary>Wide: sidebar left + list|inspector side by side.  Narrow: everything in one column.</summary>
    void ApplyLayout(bool n)
    {
        var star = new GridLength(1, GridUnitType.Star);
        var zero = new GridLength(0);

        SideCol.Width = n ? zero : new GridLength(252);
        MainCol.Width = star;
        Grid.SetRow(Sidebar, 0); Grid.SetRowSpan(Sidebar, n ? 1 : 2); Grid.SetColumn(Sidebar, 0); Grid.SetColumnSpan(Sidebar, n ? 2 : 1);
        Sidebar.Margin = n ? new Thickness(0, 0, 0, 12) : new Thickness(0, 0, 16, 0);
        Grid.SetRow(MainPane, n ? 1 : 0); Grid.SetRowSpan(MainPane, n ? 1 : 2);
        Grid.SetColumn(MainPane, n ? 0 : 1); Grid.SetColumnSpan(MainPane, n ? 2 : 1);

        Brand.Visibility = n ? Visibility.Collapsed : Visibility.Visible;
        foreach (var st in tools.Values)
        {
            st.Btn!.Width = n ? 168 : 218;
            st.Sub!.Visibility = n ? Visibility.Collapsed : Visibility.Visible;
        }

        ColA.Width = n ? star : new GridLength(380);
        ColB.Width = n ? zero : new GridLength(16);
        ColC.Width = n ? zero : star;
        RowA.Height = star;
        RowB.Height = n ? star : zero;
        Grid.SetColumn(ListPane, 0); Grid.SetRow(ListPane, 0);
        Grid.SetColumn(InspectorPane, n ? 0 : 2); Grid.SetRow(InspectorPane, n ? 1 : 0);
        InspectorPane.Margin = n ? new Thickness(0, 12, 0, 0) : new Thickness(0);
    }

    void OnDrag(object s, MouseButtonEventArgs e)
    {
        if (e.ChangedButton != MouseButton.Left) return;
        try { DragMove(); } catch { }
    }

    void OnMin(object s, RoutedEventArgs e) => WindowState = WindowState.Minimized;

    void OnClose(object s, RoutedEventArgs e)
    {
        if (closing) return;
        StashDraft();
        if (busy && MessageBox.Show(this, "A job is still running. Cancel it and exit?", "Team Arena",
                MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
        if (drafts.Count > 0 && MessageBox.Show(this, "You have unsaved edits. Exit and discard them?", "Team Arena",
                MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
        closing = true;
        cts?.Cancel();
        var fade = new DoubleAnimation(0, D(180));
        fade.Completed += (_, _) => Close();
        BeginAnimation(OpacityProperty, fade);
    }

    // ───────────────────────── intake (drop = process) ─────────────────────────
    static bool HasFiles(DragEventArgs e) => e.Data.GetDataPresent(DataFormats.FileDrop);

    void WinDragEnter(object s, DragEventArgs e)
    {
        if (!HasFiles(e)) return;
        e.Effects = DragDropEffects.Copy;
        e.Handled = true;
        DropGlow.BeginAnimation(OpacityProperty, new DoubleAnimation(1, D(160)));
    }

    void WinDragOver(object s, DragEventArgs e)
    {
        if (!HasFiles(e)) return;   // let text boxes handle their own text drags
        e.Effects = DragDropEffects.Copy;
        e.Handled = true;
    }

    void WinDragLeave(object s, DragEventArgs e)
    {
        // Leave events also fire when the cursor crosses child controls: only fade out when it really left the window.
        var p = e.GetPosition(this);
        if (p.X >= 0 && p.Y >= 0 && p.X <= ActualWidth && p.Y <= ActualHeight) return;
        DropGlow.BeginAnimation(OpacityProperty, new DoubleAnimation(0, D(240)));
    }

    void WinDrop(object s, DragEventArgs e)
    {
        DropGlow.BeginAnimation(OpacityProperty, new DoubleAnimation(0, D(600)));
        if (!HasFiles(e)) return;
        e.Handled = true;
        if (e.Data.GetData(DataFormats.FileDrop) is string[] f) AddAndRun(f);
    }

    void OnBrowse(object s, MouseButtonEventArgs e)
    {
        if (cur.Def.Folders)
        {
            var fd = new OpenFolderDialog { Title = "Choose folder(s) to pack", Multiselect = true };
            if (fd.ShowDialog(this) == true) AddAndRun(fd.FolderNames);
            return;
        }
        var masks = string.Join(";", cur.Def.Exts.Select(x => "*." + x));
        var dlg = new OpenFileDialog { Multiselect = true, Filter = $"{cur.Def.Title}|{masks}|All files|*.*" };
        if (dlg.ShowDialog(this) == true) AddAndRun(dlg.FileNames);
    }

    async void AddAndRun(string[] paths)
    {
        var st = cur;
        try
        {
            // scan + filter + build the list items on a worker thread: dropping a big folder must not freeze the window
            var (fresh, seen) = await Task.Run(() =>
            {
                var list = new List<FileItem>();
                int count = 0;
                var opt = new EnumerationOptions { RecurseSubdirectories = true, IgnoreInaccessible = true };
                bool Wanted(string f) => st.Def.Exts.Contains(Path.GetExtension(f).TrimStart('.').ToLowerInvariant());
                foreach (var p in paths)
                {
                    try
                    {
                        if (st.Def.Folders) { if (Directory.Exists(p)) { count++; list.Add(new FileItem(p)); } }
                        else if (Directory.Exists(p))
                        {
                            foreach (var f in Directory.EnumerateFiles(p, "*", opt)) { count++; if (Wanted(f)) list.Add(new FileItem(f)); }
                        }
                        else if (File.Exists(p)) { count++; if (Wanted(p)) list.Add(new FileItem(p)); }
                    }
                    catch (Exception ex) { ErrorHub.Report(ex, "INTAKE", p, true); }
                }
                return (list, count);
            });

            var added = new List<FileItem>();
            foreach (var item in fresh)
            {
                if (!st.Known.Add(item.FullPath)) continue;
                st.Items.Add(item);
                added.Add(item);
            }
            if (st == cur) UpdateCount();

            if (added.Count == 0)
            {
                Toast(st.Def.Folders ? "Drop a folder here (not single files)"
                    : seen > 0 ? "Nothing new — wrong type for this tool, or already added"
                    : "No files found");
                return;
            }

            if (st == cur && FileList.SelectedItem is null) FileList.SelectedItem = added[0];

            if (st.Def.Key == "config") { Toast($"{added.Count} file{(added.Count == 1 ? "" : "s")} added — select one to inspect"); return; }
            if (busy)
            {
                st.Pending.AddRange(added);
                foreach (var i in added) i.SetState("queued", Gray);
                Toast($"{added.Count} file{(added.Count == 1 ? "" : "s")} queued — they start when the current job finishes");
                return;
            }
            await RunAndDrain(st, added);
        }
        catch (Exception ex) { ErrorHub.Report(ex, "INTAKE"); }
    }

    /// <summary>Run a batch, then keep going with anything that was dropped while it was running.</summary>
    async Task RunAndDrain(ToolState st, IReadOnlyList<FileItem> items)
    {
        try
        {
            if (!await RunTool(st, items)) { CancelPending(); return; }
            await DrainQueue();
        }
        catch (Exception ex) { ErrorHub.Report(ex, "RUN"); }
    }

    async Task DrainQueue()
    {
        while (!busy)
        {
            var st = tools.Values.FirstOrDefault(t => t.Pending.Count > 0);
            if (st is null) return;
            var alive = st.Items.ToHashSet();   // the user may have removed some while they waited
            var batch = st.Pending.Where(alive.Contains).ToList();
            st.Pending.Clear();
            if (batch.Count == 0) continue;
            if (!await RunTool(st, batch)) { CancelPending(); return; }
        }
    }

    void CancelPending()
    {
        foreach (var t in tools.Values)
        {
            foreach (var i in t.Pending) i.SetState("cancelled", Gray);
            t.Pending.Clear();
        }
    }

    void UpdateCount() =>
        CountText.Text = cur.Items.Count == 0 ? "Nothing here yet" : $"{cur.Items.Count:N0} item{(cur.Items.Count == 1 ? "" : "s")}";

    void OnClear(object s, RoutedEventArgs e)
    {
        cur.Items.Clear(); cur.Known.Clear(); cur.Pending.Clear();
        drafts.Clear(); dirty = false;
        UpdateCount(); ResetPreview();
    }

    void OnListKey(object s, KeyEventArgs e)
    {
        if (e.Key != Key.Delete) return;
        foreach (var it in FileList.SelectedItems.Cast<FileItem>().ToList())
        {
            cur.Items.Remove(it); cur.Known.Remove(it.FullPath); cur.Pending.Remove(it);
            drafts.Remove(it.FullPath);
            if (editPath is not null && editPath.Equals(it.FullPath, StringComparison.OrdinalIgnoreCase)) { dirty = false; ResetPreview(); }
        }
        UpdateCount();
    }

    void OnRerun(object s, RoutedEventArgs e)
    {
        IEnumerable<FileItem> src = FileList.SelectedItems.Count > 0 ? FileList.SelectedItems.Cast<FileItem>() : cur.Items;
        var list = src.ToList();
        if (list.Count == 0) { Toast("Drop some files first"); return; }
        if (busy) { Toast("Busy right now — wait for the current job to finish"); return; }
        _ = RunAndDrain(cur, list);
    }

    // ───────────────────────── toast + error dialog ─────────────────────────
    void Toast(string text, bool error = false, ArenaError? err = null)
    {
        toastErr = err;
        ToastText.Text = text;
        ToastDot.Fill = new SolidColorBrush(error ? Red : Amber);
        ToastMore.Visibility = err is null ? Visibility.Collapsed : Visibility.Visible;
        ToastHost.IsHitTestVisible = true;
        var ease = new CubicEase { EasingMode = EasingMode.EaseOut };
        ToastHost.BeginAnimation(OpacityProperty, new DoubleAnimation(1, D(200)));
        ToastShift.BeginAnimation(TranslateTransform.YProperty, new DoubleAnimation(24, 0, D(300)) { EasingFunction = ease });
        ScheduleHide(error ? 9000 : 3500);
    }

    async void ScheduleHide(int ms)
    {
        toastCts?.Cancel();
        var c = toastCts = new CancellationTokenSource();
        try
        {
            await Task.Delay(ms, c.Token);
            ToastHost.IsHitTestVisible = false;
            ToastHost.BeginAnimation(OpacityProperty, new DoubleAnimation(0, D(260)));
        }
        catch (TaskCanceledException) { }
    }

    void OnToastClick(object s, MouseButtonEventArgs e)
    {
        if (toastErr is not null) ShowError(toastErr);
    }

    void ShowError(ArenaError e)
    {
        var tb = new TextBox
        {
            Text = $"Code:   {e.Code}\nTime:   {e.Time:yyyy-MM-dd HH:mm:ss}\nFile:   {e.File ?? "-"}\n\n{e.Message}\n\nHint:   {e.Hint}\n\n──── technical details ────\n{e.Detail}",
            IsReadOnly = true, FontFamily = new FontFamily("Consolas"), FontSize = 12,
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 14)
        };
        var copy = new Button { Content = "📋  Copy report", Style = (Style)FindResource("Glow") };
        copy.Click += (_, _) => { try { Clipboard.SetText(tb.Text); } catch { } };
        var log = new Button { Content = "📁  Open log folder", Style = (Style)FindResource("Ghost") };
        log.Click += (_, _) => { try { Process.Start("explorer.exe", ErrorHub.LogDir); } catch { } };

        var buttons = new StackPanel { Orientation = Orientation.Horizontal };
        buttons.Children.Add(copy); buttons.Children.Add(log);
        var grid = new Grid { Margin = new Thickness(22) };
        grid.RowDefinitions.Add(new RowDefinition());
        grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        grid.Children.Add(tb);
        Grid.SetRow(buttons, 1); grid.Children.Add(buttons);

        new Window
        {
            Title = "Team Arena · " + e.Code, Width = 760, Height = 520, Owner = this,
            WindowStartupLocation = WindowStartupLocation.CenterOwner,
            Background = Res("Bg"), Content = grid
        }.ShowDialog();
    }

    // ───────────────────────── batch engine ─────────────────────────
    void SetBusy(bool b)
    {
        busy = b;
        RerunBtn.IsEnabled = !b;
        CancelBtn.Visibility = b ? Visibility.Visible : Visibility.Collapsed;
    }

    void AnimateProgress(double v) =>
        Prog.BeginAnimation(RangeBase.ValueProperty, new DoubleAnimation(v, D(150)));

    void OnCancel(object s, RoutedEventArgs e) { cts?.Cancel(); StatusText.Text = "Cancelling…"; }

    string OutDir(string sub)
    {
        var d = Path.Combine(outRoot, sub);
        Directory.CreateDirectory(d);
        return d;
    }

    /// <summary>Thread-safe unique file name: parallel workers can no longer pick the same "free" name.</summary>
    static string Unique(string p)
    {
        lock (UniqueGate)
        {
            string d = Path.GetDirectoryName(p)!, n = Path.GetFileNameWithoutExtension(p), x = Path.GetExtension(p), c = p;
            for (int i = 2; File.Exists(c) || Reserved.Contains(c); i++) c = Path.Combine(d, $"{n}_{i}{x}");
            Reserved.Add(c);
            return c;
        }
    }

    static string UniqueDir(string p)
    {
        lock (UniqueGate)
        {
            string c = p;
            for (int i = 2; Directory.Exists(c) || Reserved.Contains(c); i++) c = $"{p}_{i}";
            Reserved.Add(c);
            Directory.CreateDirectory(c);
            return c;
        }
    }

    /// <summary>Runs one batch. Returns false if the user cancelled it. maxPar: how many files at once (0 = all cores).</summary>
    async Task<bool> RunBatch(string title, string area, IReadOnlyList<FileItem> targets, Action<FileItem, Job, CancellationToken> work, int maxPar = 0)
    {
        if (busy) return true;
        if (targets.Count == 0) return true;

        SetBusy(true);
        ReportHub.BeginBatch();
        bool report = area != "ZIP";
        Prog.BeginAnimation(RangeBase.ValueProperty, null);
        Prog.Value = 0;
        cts = new CancellationTokenSource();
        var ct = cts.Token;
        var job = new Job();
        var errors = new ConcurrentBag<ArenaError>();
        int ok = 0; bool cancelled = false; double shown = 0;
        var sw = Stopwatch.StartNew();
        foreach (var it in targets) it.SetState("queued", Gray);

        var timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(50) };
        timer.Tick += (_, _) =>
        {
            double v = Math.Min(1.0, job.Done / (double)Math.Max(1, job.Total)) * 100;
            if (v > shown) { shown = v; AnimateProgress(shown); }
            StatusText.Text = $"{title}  ·  {job.Done:N0}/{job.Total:N0}  ·  {job.Current}";
        };
        timer.Start();

        try
        {
            await Task.Run(() =>
            {
                var opt = new ParallelOptions { CancellationToken = ct, MaxDegreeOfParallelism = maxPar > 0 ? maxPar : Math.Max(2, Environment.ProcessorCount) };
                Parallel.ForEach(targets, opt, it =>
                {
                    job.Current = it.Name;
                    it.ClearWarnings();
                    it.SetState("working…", Amber);
                    try
                    {
                        work(it, job, ct);
                        if (it.Warnings.Count > 0) it.SetState("✔ done ⚠", Amber); else it.SetState("✔ done", Green);
                        Interlocked.Increment(ref ok);
                        if (report && !ReportHub.Has(it.FullPath))
                            ReportHub.Add(new ReportEntry(it.FullPath, title, "success", HashOrNull(it.FullPath), null, "completed without errors", DateTime.Now));
                    }
                    catch (OperationCanceledException) { throw; }
                    catch (Exception ex)
                    {
                        it.SetState("⚠ failed", Red);
                        var err = ErrorHub.Report(ex, area, it.FullPath, true);
                        errors.Add(err);
                        OpLog.Write(area, "FAILED", it.Name, err.Code + " | " + ex.Message);
                        if (report && !ReportHub.Has(it.FullPath))
                            ReportHub.Add(new ReportEntry(it.FullPath, title, "failed", HashOrNull(it.FullPath), null, ex.Message, DateTime.Now));
                    }
                });
            });
        }
        catch (OperationCanceledException) { cancelled = true; }
        catch (Exception ex) { errors.Add(ErrorHub.Report(ex, area, null, true)); }

        timer.Stop();
        sw.Stop();
        if (report) ReportHub.Flush();
        string t = $"{sw.Elapsed.TotalSeconds:0.0}s";
        AnimateProgress(cancelled ? shown : 100);

        if (cancelled)
        {
            foreach (var it in targets.Where(i => i.Status is "queued" or "working…")) it.SetState("cancelled", Gray);
            StatusText.Text = "Cancelled"; Toast("Cancelled");
        }
        else if (errors.IsEmpty)
        {
            var notes = targets.SelectMany(i => i.Warnings.Select(w => targets.Count > 1 ? $"[{i.Name}] {w}" : w)).ToList();
            StatusText.Text = $"✔  {title} finished  ·  {ok}/{targets.Count}  ·  {t}" + (notes.Count > 0 ? $"  ·  {notes.Count} note{(notes.Count == 1 ? "" : "s")}" : "");
            if (notes.Count == 0) Toast($"{title}: done in {t}");
            else
            {
                string head = $"{title}: done in {t}  ·  {notes.Count} note{(notes.Count == 1 ? "" : "s")}";
                var warn = ErrorHub.Warn(area, head, string.Join(Environment.NewLine, notes.Take(200)));
                Toast(head + "   ·   " + warn.Code, false, warn);
            }
        }
        else
        {
            var first = errors.First();
            StatusText.Text = $"⚠  {title}  ·  {ok} ok, {errors.Count} failed  ·  {t}";
            Toast($"{errors.Count} failed  ·  {first.Message}   ·   {first.Code}", true, first);
        }

        SetBusy(false);
        _ = ResetProgressLater();
        return !cancelled;
    }

    async Task ResetProgressLater()
    {
        await Task.Delay(1500);
        if (!busy) AnimateProgress(0);
    }

    // ───────────────────────── tools ─────────────────────────
    Task<bool> RunTool(ToolState st, IReadOnlyList<FileItem> t)
    {
        switch (st.Def.Key)
        {
            case "rez":
            {
                bool deep = DeepBox.IsChecked == true;
                // each archive already extracts in parallel inside: one archive at a time avoids disk thrashing
                return RunBatch("Unpacking REZ", "REZ", t, (it, job, ct) =>
                {
                    string dir = UniqueDir(Path.Combine(OutDir("Unpacked"), Path.GetFileNameWithoutExtension(it.Name)));
#if CFREZ
                    RezBackend.Unpack(it.FullPath, dir, job, ct);   // real-client layout (encrypted directory tables)
#else
                    RezArchive.Open(it.FullPath).ExtractAll(dir, job, ct);
#endif
                    if (deep) ConvertDtxTree(dir, job, ct, m => it.Warn(m));
                }, 1);
            }
            case "pack":
                return RunBatch("Packing REZ", "REZ", t, (it, job, ct) =>
                {
                    string dst = Unique(Path.Combine(OutDir("Packed"), it.Name + ".rez"));
#if CFREZ
                    RezBackend.PackStaged(it.FullPath, dst, job, ct, m => it.Warn(m));   // real-client layout; verified by re-reading
#else
                    RezArchive.Pack(it.FullPath, dst, job, ct, m => it.Warn(m));   // built-in v1 layout (NOT the real client layout), verified
                    it.Warn("Built-in REZ writer used: plain v1 layout. Run setup.bat and rebuild to use the real-client layout.");
#endif
                    OpLog.Write("REZ", "verify", it.Name, "packed archive re-opened; entry list, sizes and per-entry SHA-256 verified");
                    ReportHub.Add(new ReportEntry(it.FullPath, "REZ Pack", "success", null, Integrity.Sha256(dst),
                        "re-opened after packing; entry list, sizes and per-entry SHA-256 verified", DateTime.Now, dst));
                }, 1);

            case "dtx":
                return RunBatch("DTX → PNG", "DTX", t, (it, job, ct) =>
                {
                    job.Add(1);
                    var (w, h, px) = DtxCodec.Decode(File.ReadAllBytes(it.FullPath));
                    ImageTools.SavePng(w, h, px, Unique(Path.Combine(OutDir("DTX_to_PNG"), Path.GetFileNameWithoutExtension(it.Name) + ".png")));
                    job.Tick();
                });

            case "png2dtx":
            {
                bool compress = DxtBox.IsChecked == true;
                return RunBatch("PNG → DTX", "DTX", t, (it, job, ct) =>
                {
                    job.Add(1);
                    var (w, h, px) = ImageTools.LoadBgra(it.FullPath);
                    // a .dtx beside the image (foo.dtx next to foo.png / foo.dtx.png) lends its header, format and mip count
                    var tpl = DtxCodec.FindTemplate(it.FullPath);
                    int bpp = compress ? (tpl is not null && tpl.Bpp >= DtxCodec.BppDxt1 ? tpl.Bpp : DtxCodec.AutoDxt(px))
                                       : (tpl?.Bpp ?? DtxCodec.Bpp32);
                    var data = DtxCodec.Encode(w, h, px, bpp, tpl?.Mips ?? 1, tpl, m => it.Warn(m));
                    Atomic.WriteBytes(Unique(Path.Combine(OutDir("PNG_to_DTX"), Path.GetFileNameWithoutExtension(it.Name) + ".dtx")), data);
                    job.Tick();
                });
            }

            case "resize":
            {
                int? w = Num(WBox.Text), h = Num(HBox.Text);
                double? pct = double.TryParse(PBox.Text.Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out var pv) && pv > 0 ? pv : null;
                bool keep = KeepBox.IsChecked == true;
                if (w is null && h is null && pct is null)
                {
                    foreach (var i in t) i.SetState("set a size", Amber);
                    Toast("Enter a width, a height, or a scale % — then press “Run again”");
                    return Task.FromResult(true);
                }
                return RunBatch("Resizing", "IMG", t, (it, job, ct) =>
                {
                    job.Add(1);
                    var (sw, sh, spx) = ImageTools.LoadAny(it.FullPath);
                    var (nw, nh) = ImageTools.Compute(sw, sh, w, h, keep, pct);
                    string ext = (it.Ext is "jpg" or "jpeg" or "bmp") ? "." + it.Ext : ".png";
                    string dst = Unique(Path.Combine(OutDir("Resized"), $"{Path.GetFileNameWithoutExtension(it.Name)}_{nw}x{nh}{ext}"));
                    ImageTools.Save(nw, nh, ImageTools.ResizePixels(spx, sw, sh, nw, nh, ct), dst);
                    job.Tick();
                });
            }

            case "icons":
                return RunBatch("Extracting icons", "ICON", t, (it, job, ct) =>
                    IconExtractor.ExtractAll(it.FullPath, Path.Combine(OutDir("Icons"), Path.GetFileNameWithoutExtension(it.Name)), job, ct));

            case "cft": case "ltc": case "enc": case "dat": case "fx": case "ltbglb":
            {
                string key = st.Def.Key;
                var c = ArenaConfig.Load();   // re-read: config.json can be edited while the app is open
                return RunBatch("Converting", key.ToUpperInvariant(), t, (it, job, ct) =>
                {
                    job.Add(1);
                    var spec = SpecFor(key, it.Ext);
                    lock (extGate) Pipeline.Convert(c, spec, it.FullPath, OutDir(spec.Tool), Workspace.BackupDir, ct);
                    job.Tick();
                });
            }

            case "ltb":
                return RunBatch("LTB info", "LTB", t, (it, job, ct) =>
                {
                    job.Add(1);
                    string sha = Integrity.Sha256(it.FullPath);
                    using var fs = new FileStream(it.FullPath, FileMode.Open, FileAccess.Read, FileShare.Read);
                    var head = new byte[Math.Min(fs.Length, 256)];
                    fs.ReadExactly(head);
                    string txt = $"File:    {it.Name}\nSize:    {fs.Length:N0} bytes\nSHA-256: {sha}\n\nFirst {head.Length} bytes (raw hex, not interpreted):\n{HexDump(head, fs.Length)}\n" +
                                 "Full LTB parsing/conversion: unconfirmed, needs reverse engineering - not attempted.\n";
                    string dst = Unique(Path.Combine(OutDir("LTB_info"), Path.GetFileNameWithoutExtension(it.Name) + ".txt"));
                    File.WriteAllText(dst, txt);
                    OpLog.Write("LTB", "info", it.Name, $"size={fs.Length}; sha256={sha}");
                    ReportHub.Add(new ReportEntry(it.FullPath, "LTB info", "success", sha, sha,
                        "read-only info (size, hash, raw header bytes); full conversion unconfirmed", DateTime.Now, dst));
                    job.Tick();
                });

            case "unsup":
                return UnsupportedAsync(t);

            default:
                return Task.FromResult(true);
        }
    }

    static string? HashOrNull(string path)
    {
        try { return File.Exists(path) ? Integrity.Sha256(path) : null; } catch { return null; }
    }

    async Task<bool> UnsupportedAsync(IReadOnlyList<FileItem> t)
    {
        ReportHub.BeginBatch();
        await Task.Run(() =>
        {
            foreach (var it in t)
            {
                string note = $".{it.Ext} is unconfirmed - needs reverse engineering. Not implemented and the file was not touched.";
                ReportHub.Add(new ReportEntry(it.FullPath, "." + it.Ext.ToUpperInvariant(), "unsupported",
                    HashOrNull(it.FullPath), null, note, DateTime.Now));
                OpLog.Write(it.Ext.ToUpperInvariant(), "skip", it.Name, "unsupported format");
            }
            ReportHub.Flush();
        });
        foreach (var it in t) it.SetState("unsupported", Amber);
        StatusText.Text = $"{t.Count} file{(t.Count == 1 ? "" : "s")} listed as unsupported (see report)";
        Toast("Unsupported formats: reported only, files untouched");
        return true;
    }

    static int? Num(string s) => int.TryParse(s.Trim(), out var v) && v > 0 ? v : null;

    /// <summary>Deep unpack: convert every extracted DTX to PNG next to it. Textures that cannot be converted are skipped and reported.</summary>
    static void ConvertDtxTree(string dir, Job job, CancellationToken ct, Action<string>? warn = null)
    {
        var files = Directory.GetFiles(dir, "*.dtx", SearchOption.AllDirectories);
        job.Add(files.Length);
        var skipped = new ConcurrentBag<string>();
        var opt = new ParallelOptions { CancellationToken = ct, MaxDegreeOfParallelism = Math.Max(2, Environment.ProcessorCount) };
        Parallel.ForEach(files, opt, f =>
        {
            try
            {
                var (w, h, px) = DtxCodec.Decode(File.ReadAllBytes(f));
                string png = Path.ChangeExtension(f, ".png");
                if (File.Exists(png)) png = Path.ChangeExtension(f, ".dtx.png");
                ImageTools.SavePng(w, h, px, png);
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                ErrorHub.Report(ex, "DTX", f, true);
                skipped.Add($"{Path.GetRelativePath(dir, f)}: {ex.Message}");
            }
            job.Tick();
        });
        if (!skipped.IsEmpty && warn is not null)
        {
            warn($"{skipped.Count} of {files.Length} textures could not be converted to PNG and were skipped:");
            foreach (var m in skipped.OrderBy(x => x).Take(25)) warn("   " + m);
            if (skipped.Count > 25) warn($"   … and {skipped.Count - 25} more (see the log).");
        }
    }

    async void OnZip(object s, RoutedEventArgs e)
    {
        if (busy) { Toast("Busy right now — wait for the current job to finish"); return; }
        if (!Directory.Exists(outRoot) || !Directory.EnumerateFileSystemEntries(outRoot).Any())
        { Toast("Nothing to zip yet — drop some files first"); return; }
        var dlg = new SaveFileDialog { Filter = "ZIP archive|*.zip", FileName = "Arena_Output.zip" };
        if (dlg.ShowDialog(this) != true) return;
        string zipPath = dlg.FileName;

        await RunBatch("Zipping", "ZIP", new[] { new FileItem(outRoot) }, (it, job, ct) =>
        {
            var files = Directory.GetFiles(outRoot, "*", SearchOption.AllDirectories)
                                 .Where(f => !f.Equals(zipPath, StringComparison.OrdinalIgnoreCase)).ToArray();
            job.Add(files.Length);
            Atomic.Write(zipPath, tmp =>
            {
                using var z = ZipFile.Open(tmp, ZipArchiveMode.Create);
                foreach (var f in files)
                {
                    ct.ThrowIfCancellationRequested();
                    z.CreateEntryFromFile(f, Path.GetRelativePath(outRoot, f).Replace('\\', '/'), CompressionLevel.Fastest);
                    job.Tick();
                }
            });
        });
        await DrainQueue();
    }

    void OnConfig(object s, RoutedEventArgs e)
    {
        try
        {
            ArenaConfig.Load();   // makes sure config.json exists
            Process.Start(new ProcessStartInfo("notepad.exe", $"\"{ArenaConfig.FilePath}\"") { UseShellExecute = true });
            Toast("Edit config.json, save it, then press “Run again”");
        }
        catch (Exception ex) { ErrorHub.Report(ex, "CONFIG", ArenaConfig.FilePath); }
    }

    void OnReport(object s, RoutedEventArgs e)
    {
        try
        {
            var path = ReportHub.Flush();
            if (path is null || ReportHub.Snapshot().Count == 0) { Toast("No report yet — convert something first"); return; }
            Process.Start(new ProcessStartInfo("explorer.exe", $"/select,\"{path}\"") { UseShellExecute = true });
        }
        catch (Exception ex) { ErrorHub.Report(ex, "REPORT"); }
    }

    void OnOpenOut(object s, RoutedEventArgs e)
    {
        try { Directory.CreateDirectory(outRoot); Process.Start("explorer.exe", outRoot); }
        catch (Exception ex) { ErrorHub.Report(ex, "OPEN"); }
    }

    // ───────────────────────── inspector ─────────────────────────
    /// <summary>Remember unsaved edits of the file being edited, so changing selection never loses them.</summary>
    void StashDraft()
    {
        if (dirty && editPath is not null) drafts[editPath] = PreviewText.Text;
    }

    void SetEditLabel() =>
        ModeLabel.Text = editLabel + (editAnsi ? "   ·   ANSI (bytes kept)" : "") + (dirty ? "   ·   ● UNSAVED" : "   ·   EDITABLE");

    void OnEdit(object s, TextChangedEventArgs e)
    {
        if (suppressEdit || editPath is null || dirty) return;
        dirty = true;
        SetEditLabel();
    }

    void ResetPreview()
    {
        StashDraft();
        dirty = false;
        editPath = null;
        PreviewImage.Visibility = PreviewText.Visibility = SaveBtn.Visibility = Visibility.Collapsed;
        EmptyHint.Visibility = Visibility.Visible;
        ModeLabel.Text = "INSPECTOR";
    }

    async void OnSelect(object s, SelectionChangedEventArgs e)
    {
        if (FileList.SelectedItems.Count != 1 || FileList.SelectedItem is not FileItem it) return;
        int my = ++ticket;
        try { await ShowPreview(it, my); }
        catch (Exception ex) { if (my == ticket) ErrorHub.Report(ex, "VIEW", it.FullPath); }
    }

    async Task ShowPreview(FileItem it, int my)
    {
        StashDraft();
        dirty = false;
        editPath = null;
        ModeLabel.Text = it.Name.ToUpperInvariant();

        if (it.Ext == "dir")
        {
            var info = await Task.Run(() =>
            {
                var opt = new EnumerationOptions { RecurseSubdirectories = true, IgnoreInaccessible = true };
                var files = Directory.EnumerateFiles(it.FullPath, "*", opt).ToList();
                long total = files.Sum(f => { try { return new FileInfo(f).Length; } catch { return 0L; } });
                return $"Folder\n{it.FullPath}\n\n{files.Count:N0} files  ·  {FileItem.Human(total)}";
            });
            if (my != ticket) return;
            ShowText(info, false);
        }
        else if (ImgExt.Contains(it.Ext))
        {
            var bmp = await Task.Run(() =>
            {
                var b = new BitmapImage();
                b.BeginInit(); b.CacheOption = BitmapCacheOption.OnLoad; b.UriSource = new Uri(it.FullPath); b.EndInit(); b.Freeze();
                return (BitmapSource)b;
            });
            if (my != ticket) return;
            ShowImage(bmp);
            ModeLabel.Text += $"   ·   {bmp.PixelWidth}×{bmp.PixelHeight}";
        }
        else if (it.Ext == "dtx")
        {
            var (bmp, info) = await Task.Run(() =>
            {
                var bytes = File.ReadAllBytes(it.FullPath);
                var (w, h, px) = DtxCodec.Decode(bytes);
                var b = BitmapSource.Create(w, h, 96, 96, PixelFormats.Bgra32, null, px, w * 4);
                b.Freeze();
                return ((BitmapSource)b, DtxCodec.Info(bytes));
            });
            if (my != ticket) return;
            ShowImage(bmp);
            ModeLabel.Text += $"   ·   {bmp.PixelWidth}×{bmp.PixelHeight}" + (info.Length > 0 ? "   ·   " + info : "");
        }
        else if (it.Ext == "rez")
        {
            var text = await Task.Run(() =>
            {
#if CFREZ
                var ca = new CFRezManager.RezArchiveReader().Read(it.FullPath);
                var list = new List<(long size, string path)>();
                void Walk(CFRezManager.RezDirectoryNode d) { foreach (var c in d.Children) { if (c is CFRezManager.RezDirectoryNode sd) Walk(sd); else if (c is CFRezManager.RezFileNode f) list.Add((f.Size, f.FullPath)); } }
                Walk(ca.Root);
                var sb = new StringBuilder($"REZ archive  ·  {list.Count:N0} entries  ·  {FileItem.Human(list.Sum(x => x.size))}\n\n");
                foreach (var en in list.Take(500)) sb.AppendLine($"{en.size,12:N0}  {en.path}");
                if (list.Count > 500) sb.AppendLine($"\n… +{list.Count - 500:N0} more");
                return sb.ToString();
#else
                var a = RezArchive.Open(it.FullPath);
                var sb = new StringBuilder($"REZ archive  ·  {a.Entries.Count:N0} entries  ·  {FileItem.Human(a.TotalBytes)}\n\n");
                foreach (var en in a.Entries.Take(500)) sb.AppendLine($"{en.Size,12:N0}  {en.Path}");
                if (a.Entries.Count > 500) sb.AppendLine($"\n… +{a.Entries.Count - 500:N0} more");
                return sb.ToString();
#endif
            });
            if (my != ticket) return;
            ShowText(text, false);
        }
        else if (TextExt.Contains(it.Ext) && new FileInfo(it.FullPath).Length < 2_000_000)
        {
            var (text, enc, nl) = await Task.Run(() =>
            {
                var bytes = File.ReadAllBytes(it.FullPath);
                Encoding en = bytes.Length >= 2 && bytes[0] == 0xFF && bytes[1] == 0xFE ? Encoding.Unicode
                            : bytes.Length >= 2 && bytes[0] == 0xFE && bytes[1] == 0xFF ? Encoding.BigEndianUnicode
                            : bytes.Length >= 3 && bytes[0] == 0xEF && bytes[1] == 0xBB && bytes[2] == 0xBF ? new UTF8Encoding(true)
                            : new UTF8Encoding(false, true);   // strict: invalid bytes throw instead of becoming "?"
                string t;
                try
                {
                    using var sr = new StreamReader(new MemoryStream(bytes), en, true);
                    t = sr.ReadToEnd();
                }
                catch (DecoderFallbackException)
                {
                    // not UTF-8 (old ANSI / Korean / Chinese config): Latin-1 maps every byte 1:1, so saving restores the exact bytes
                    en = Encoding.Latin1;
                    t = en.GetString(bytes);
                }
                string newline = t.Contains("\r\n") ? "\r\n" : t.Contains('\n') ? "\n" : "\r\n";
                return (t, en, newline);
            });
            if (my != ticket) return;
            editEnc = enc; editNl = nl; editPath = it.FullPath;
            editAnsi = ReferenceEquals(enc, Encoding.Latin1);
            editLabel = it.Name.ToUpperInvariant();
            bool restored = drafts.TryGetValue(it.FullPath, out var draft);
            ShowText(restored ? draft! : text, true);
            dirty = restored;
            SetEditLabel();
        }
        else
        {
            var hex = await Task.Run(() =>
            {
                using var fs = new FileStream(it.FullPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                var buf = new byte[Math.Min(fs.Length, 65536)];
                fs.ReadExactly(buf);
                return HexDump(buf, fs.Length);
            });
            if (my != ticket) return;
            ShowText(hex, false);
            ModeLabel.Text += "   ·   HEX";
            if (it.Ext is "dll" or "exe" or "ocx")
            {
                int icons = await Task.Run(() => IconExtractor.Count(it.FullPath));
                if (my == ticket) ModeLabel.Text += $"   ·   {icons} icon{(icons == 1 ? "" : "s")}";
            }
        }
    }

    static string HexDump(byte[] b, long total)
    {
        var sb = new StringBuilder();
        for (int i = 0; i < b.Length; i += 16)
        {
            sb.Append(i.ToString("X8")).Append("  ");
            for (int j = 0; j < 16; j++) sb.Append(i + j < b.Length ? b[i + j].ToString("X2") + " " : "   ");
            sb.Append(' ');
            for (int j = 0; j < 16 && i + j < b.Length; j++) { char c = (char)b[i + j]; sb.Append(c is >= ' ' and < (char)127 ? c : '.'); }
            sb.AppendLine();
        }
        if (total > b.Length) sb.AppendLine($"\n… {total - b.Length:N0} more bytes not shown");
        return sb.ToString();
    }

    void ShowImage(ImageSource src)
    {
        PreviewImage.Source = src;
        PreviewText.Visibility = SaveBtn.Visibility = EmptyHint.Visibility = Visibility.Collapsed;
        PreviewImage.Visibility = Visibility.Visible;
        var ease = new CubicEase { EasingMode = EasingMode.EaseOut };
        PreviewImage.BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, D(260)));
        var pop = new DoubleAnimation(0.94, 1, D(320)) { EasingFunction = ease };
        ImgScale.BeginAnimation(ScaleTransform.ScaleXProperty, pop);
        ImgScale.BeginAnimation(ScaleTransform.ScaleYProperty, pop);
    }

    void ShowText(string text, bool editable)
    {
        suppressEdit = true;
        PreviewText.Text = text;
        suppressEdit = false;
        PreviewText.IsReadOnly = !editable;
        PreviewImage.Visibility = EmptyHint.Visibility = Visibility.Collapsed;
        PreviewText.Visibility = Visibility.Visible;
        SaveBtn.Visibility = editable ? Visibility.Visible : Visibility.Collapsed;
        PreviewText.BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, D(220)));
    }

    void OnSave(object s, RoutedEventArgs e)
    {
        if (editPath is null) return;
        string path = editPath, tmp = path + ".arn_tmp";
        try
        {
            string text = PreviewText.Text.Replace("\r\n", "\n");
            if (editAnsi && text.Any(ch => ch > 255))
            {
                var ans = MessageBox.Show(this,
                    "This file uses a single-byte (ANSI) encoding, but the text now contains characters it cannot store (they would turn into '?').\n\nSave as UTF-8 instead?",
                    "Team Arena", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                if (ans != MessageBoxResult.Yes) return;
                editEnc = new UTF8Encoding(false);
                editAnsi = false;
            }
            if (editNl == "\r\n") text = text.Replace("\n", "\r\n");   // keep the file's original line endings
            if (File.Exists(path) && !File.Exists(path + ".bak")) File.Copy(path, path + ".bak");
            File.WriteAllText(tmp, text, editEnc);   // write beside it first, then swap: a crash can't leave a half-written config
            File.Move(tmp, path, true);
            dirty = false; drafts.Remove(path);
            SetEditLabel();
            Toast("Saved  ·  original kept as .bak");
        }
        catch (Exception ex)
        {
            try { File.Delete(tmp); } catch { }
            ErrorHub.Report(ex, "SAVE", path);
        }
    }
}
